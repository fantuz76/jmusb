/*************************************************************************
 * DISCLAIMER *
 * Services performed by FREESCALE in this matter are performed          *
 * AS IS and without any warranty. CUSTOMER retains the final decision   *
 * relative to the total design and functionality of the end product.    *
 * FREESCALE neither guarantees nor will be held liable by CUSTOMER      *
 * for the success of this project. FREESCALE disclaims all warranties,  *
 * express, implied or statutory including, but not limited to,          *
 * implied warranty of merchantability or fitness for a particular       *
 * purpose on any hardware, software ore advise supplied to the project  *
 * by FREESCALE, and or any product resulting from FREESCALE services.   *
 * In no event shall FREESCALE be liable for incidental or consequential *
 * damages arising out of this agreement. CUSTOMER agrees to hold        *
 * FREESCALE harmless against any and all claims demands or actions      *
 * by anyone on account of any damage, or injury, whether commercial,    *
 * contractual, or tortuous, rising directly or indirectly as a result   *
 * of the advise or assistance supplied CUSTOMER in connection with      *
 * product, services or goods supplied under this Agreement.             *
 *************************************************************************/
/*************************************************************************************************
 * File name   : Usb_Description.c
 * Description : This file defines the USB descriptor and intizlize them 
 * History     :
 * 04/01/2007  : Initial Development
 * 
 *************************************************************************************************/

#include "typedef.h"
#include "Usb_Descriptor.h"
#include "Usb_Config.h"
#include "Hid.h"


const byte Hid_Rpt[HID_RPT_SIZE]  = 
{
    0x05, 0x01, /* Usage Page (Generic Desktop)  */         
    0x09, 0x02, /* Usage (Mouse)                 */          
    0xA1, 0x01, /* Collection (Application)      */         
    0x09, 0x01, /* Usage (Pointer)               */         
    0xA1, 0x00, /* Collection (Physical)         */         
    0x05, 0x09, /* Usage Page (Buttons)          */     
    0x19, 0x01, /* Usage Minimum (01)            */     
    0x29, 0x03, /* Usage Maximum (03)            */     
    0x15, 0x00, /* Logical Minimum (0)           */     
    0x25, 0x01, /* Logical Maximum (0)           */     
    0x75, 0x01, /* Report Size (1)               */     
    0x95, 0x03, /* Report Count (3)              */      
    0x81, 0x02, /* Input (Data, Variable, Absolute)*/    
    0x75, 0x05, /* Report Size (5)                 */    
    0x95, 0x01, /* Report Count (1)                */    
    0x81, 0x01, /* Input (Constant)    ;5 bit padding */ 
    0x05, 0x01, /* Usage Page (Generic Desktop)       */ 
    0x09, 0x30, /* Usage (X)                          */
    0x09, 0x31, /* Usage (Y)                       */  
    0x09, 0x38, /* Usage (Wheel)                   */       
    0x15, 0x81, /* Logical Minimum (-127)          */    
    0x25, 0x7F, /* Logical Maximum (127)           */    
    0x75, 0x08, /* Report Size (8)                 */    
    0x95, 0x03, /* Report Count (3)                */    
    0x81, 0x06, /* Input (Data, Variable, Relative)*/    
    0xC0, 0xC0  /* End                             */
 };
  
  
const USB_DEV_DSC Device_Dsc =
{    
    sizeof(USB_DEV_DSC),    /* Size of this descriptor in bytes     */
    DSC_DEV,                /* DEVICE descriptor type               */
    0x0002,                 /* USB Spec Release Number in BCD format*/
    0x00,                   /* Class Code                           */
    0x00,                   /* Subclass code                        */
    0x00,                   /* Protocol code                        */
    EP0_BUFF_SIZE,          /* Max packet size for EP0,             */
    0x2504,                 /* Vendor ID		//little-endian for USB */
    0x0100,                 /* Product ID:	//little-endian for USB */
    0x0002,                 /* Device release number in BCD format  */
    0x00,                   /* Manufacturer string index            */
    0x02,                   /* Product string index                 */
    0x00,                   /* Device serial number string index    */
    0x01                    /* Number of possible configurations    */
};

 const USB_CFG  Cfg_01={
    {
    sizeof(USB_CFG_DSC),    /* Size of this descriptor in bytes   */
    DSC_CFG,                /* CONFIGURATION descriptor type      */
    (word) ((sizeof(USB_CFG)<<8) | (sizeof(USB_CFG)>>8)),          /* Total length of data for this cfg*/
    1,                      /* Number of interfaces in this cfg   */
    1,                      /* Index value of this configuration  */
    0,                      /* Configuration string index         */
    _DEFAULT|_REMOTEWAKEUP, /* Attributes, see usbdefs_std_dsc.h  */
    50                      /* Max power consumption (2X mA)      */
    },
    /* Interface Descriptor */
    {
    sizeof(USB_INTF_DSC),   /* Size of this descriptor in bytes   */
    DSC_INTF,               /* INTERFACE descriptor type          */
    0,                      /* Interface Number                   */
    0,                      /* Alternate Setting Number           */
    2,                      /* Number of endpoints in this intf   */
    HID_INTF,               /* Class code                         */
    BOOT_INTF_SUBCLASS,     /* Subclass code                      */
    HID_PROTOCOL_MOUSE,     /* Protocol code                      */
    0                       /* Interface string index             */
    },
    /* HID Class-Specific Descriptor */
    {
      
    sizeof(USB_HID_DSC),    /* Size of this descriptor in bytes   */
    DSC_HID,                /* HID descriptor type                */
    0x1101,                 /* HID Spec Release Number in BCD format; ***Little-endian***/
    0x00,                   /* Country Code (0x00 for Not supported)*/
    HID_NUM_OF_DSC,         /* Number of class descriptors, see usbcfg.h */
    {
    DSC_RPT,                /* Report descriptor type  */
    (word) ((sizeof(Hid_Rpt)<<8) | (sizeof(Hid_Rpt)>>8))   /* Size of the report descripton*/
    }
    },
    /* Endpoint Descriptor*/
    {sizeof(USB_EP_DSC),DSC_EP,_EP01_IN,_INT,(word)(HID_INT_IN_EP_SIZE << 8),20} ,
    {sizeof(USB_EP_DSC),DSC_EP,_EP02_OUT,_INT,(word)(HID_INT_OUT_EP_SIZE << 8),20}
};

struct
{
  byte bLength;
  byte bDscType;
  word string[1];
} const sd000 
= {sizeof(sd000),DSC_STR,0x0904};

struct
{
  byte bLength;
  byte bDscType;
  word string[25];
} const sd001
  ={
    sizeof(sd001),DSC_STR,
    'F','r','e','e','s','c','a','l','e',' ',
    'T','e','c','h','n','o','l','o','g','y',' ','I','n','c','.'
   }; 
       
struct
{
  byte bLength;
  byte bDscType;
  word string[33];
} const sd002
={
    sizeof(sd002),DSC_STR,
    ' ',' ','J','M','6','0',' ','F','S',' ','U','S','B',' ',
    'D','e','m','o',' ','B','o','a','r','d',' ','(','C',')',
    ' ','2','0','0','7'
   }; 
   

    
unsigned char* Str_Des[] = 
    { (unsigned char*)&sd000,(unsigned char*)&sd001,(unsigned char*)&sd002};   

unsigned char* Cfg_Des[] =
    {(unsigned char*)&Cfg_01,(unsigned char*)&Cfg_01 };
    
pFunc Class_Req_Handler[1] = { &HIDClass_Request_Handler };


