/*************************************************************************
 * DISCLAIMER *
 * Services performed by FREESCALE in this matter are performed          *
 * AS IS and without any warranty. CUSTOMER retains the final decision   *
 * relative to the total design and functionality of the end product.    *
 * FREESCALE neither guarantees nor will be held liable by CUSTOMER      *
 * for the success of this project. FREESCALE disclaims all warranties,  *
 * express, implied or statutory including, but not limited to,          *
 * implied warranty of merchantability or fitness for a particular       *
 * purpose on any hardware, software ore advise supplied to the project  *
 * by FREESCALE, and or any product resulting from FREESCALE services.   *
 * In no event shall FREESCALE be liable for incidental or consequential *
 * damages arising out of this agreement. CUSTOMER agrees to hold        *
 * FREESCALE harmless against any and all claims demands or actions      *
 * by anyone on account of any damage, or injury, whether commercial,    *
 * contractual, or tortuous, rising directly or indirectly as a result   *
 * of the advise or assistance supplied CUSTOMER in connection with      *
 * product, services or goods supplied under this Agreement.             *
 *************************************************************************/
/*************************************************************************************************
 * Copyright (c) 2007, Freescale Semiconductor
 * Freescale Application Note
 *
 * File name   : main.c
 * Project name: JM60 Evaluation code
 *
 * Description : This software is the demo code JM60 
 *               The main purpose is for USB module evaluation
 *
 * Compiler    : CodeWarrior V5.1 for HC(S)08
 *
 * History     :
 * 04/01/2007  : Initial Development
 * 
 *************************************************************************************************/
#include <hidef.h>      /* for EnableInterrupts macro */
#include "derivative.h" /* include peripheral declarations */
#include "Usb_Drv.h" 
#include "Usb_Config.h"
#include "adc.h"
#include "hid.h"
#include "mouse.h"
#include "kbi.h"
#include "rtc.h"

/*Local function definition*/ 
void Init_Sys(void);
void Mcu_Init(void);
void MCG_Init(void);


void main(void) 
{
  Init_Sys();                         /*initial the system*/
  
  EnableInterrupts;                   /* enable interrupts */


  for(;;) 
  {
    __RESET_WATCHDOG();                /* feeds the dog  */ 
    
    Check_USBBus_Status();             /* Must use polling method*/
    
    Usr_Task();                        /* User task---Mouse, LED transaction */

  } 
}


/*****************************************************************************
 * Init_Sys: Initialize the system
 * Input: 	 None
 * Output:   None
 *
 ****************************************************************************/
void Init_Sys(void)
{
	Mcu_Init(); 

	MCG_Init();	//initialize the MCG to generate 24MHz bus clock

	Initialize_USBModule(); 

	Sw_Init();
  ADC_Init();
  Kbi_Init();
  Rtc_Init();               
}


/*****************************************************************************
 * Function     MCU_Init
 * Overview:    Initialization of the MCU.
 *              It will configure the JM60 to disable STOP and COP Modules.
 *              It also set the MCG configuration and bus clock frequency.
 *
 * Input  : None
 *
 * Return : None
 ****************************************************************************/
void Mcu_Init()
{
	SOPT1 = 0xF3; 			  /*Enable the COP,  and enable the MCU stop mode*/
			                  /*  
                         *  0b00000010
                         *    ||||||||__ bit0:   
                         *    |||||||___ bit1: 
                         *    ||||||____ bit2: 
                         *    |||||_____ bit3: 
                         *    ||||______ bit4: 
                         *    |||_______ bit5: STOP Mode enable
                         *    ||________ bit6: COP configuration
                         *    |_________ bit7: COP configuration
                         */
	SOPT2 = 	0x00;
			                  /*  
                         *  0b00000010
                         *    ||||||||__ bit0:   ACIC  		ACMP output connect to TPM channel 0
                         *    |||||||___ bit1:   SPI2FE		SPI2 input filter enable
                         *    ||||||____ bit2:   SPI1FE		SPI1 input filter enable
                         *    |||||_____ bit3:   
                         *    ||||______ bit4: 
                         *    |||_______ bit5:   COPW COP Window
                         *    ||________ bit6:   COPCLKS	COP wactchdog clock select
                         *    |_________ bit7:   COPCLKS	COP wactchdog clock select
                         */
	SPMSC1 = 0x40;
			                  /*  
                         *  0b01000010
                         *    ||||||||__ bit0:   BGBE  		Bandgap Buffer enable
                         *    |||||||___ bit1:   0			
                         *    ||||||____ bit2:   LVDE		Low_Voltage detect enable
                         *    |||||_____ bit3:   LVDSE		Low_Voltage Detect in stop mode
                         *    ||||______ bit4:   LVDRE		Low_Voltage Detect Reset Enable
                         *    |||_______ bit5:   LVWIE		Low_Voltage Warning interrupt Enable
                         *    ||________ bit6:   LVWACK	Low-Voltage Warning Acknowledge
                         *    |_________ bit7:   LVWF		Low_Voltage Warning Flag
                         */
  SPMSC2 = 0x00;
		                  	/*  
                         *  0b01000010
                         *    ||||||||__ bit0:   PPDC  		Partlal Power Down Control
                         *    |||||||___ bit1:   0			
                         *    ||||||____ bit2:   PPDACK	Partlal Power Down Acknowledge
                         *    |||||_____ bit3:   PPDF		partlal Power Down Flag
                         *    ||||______ bit4:   LVWV		Low-Voltage Warning Voltage Select
                         *    |||_______ bit5:   LVDV		Low_Voltage Detect Voltage select
                         *    ||________ bit6:   0
                         *    |_________ bit7:   0
                         */
  
  /*IRQSC = 0x02;*/   /*enable the IRQ interrupt */
			
	/*IO configuration*/
	PTAD = 0x00;			/*only PTA0--PTA5 are available for JM60*/
  PTADD = 0xFF;     /*Set output direction*/
	PTAPE = 0x00;		  /*Pull-up disable*/
	PTASE = 0x00; 		/*slew rate control*/
	PTADS = 0x00;	  	/*drive strength*/

		
	PTBD = 0x00;			/*PTB0--PTB7 are all available for JM60*/
  PTBDD = 0xFF;     /*Set output direction	//PTB.0--3 are used to output to drive the LEDs(1-4) */
	PTBPE = 0x00;	  	/*Pull-up disable*/
	PTBSE = 0x00; 		/*slew rate control*/
	PTBDS = 0x00;	  	/*drive strength*/
	
	PTCD = 0x00;			/*PTC7 is not  available for JM60*/
  PTCDD = 0xFF;     /*Set output direction*/
	PTCPE = 0x00;	  	/*Pull-up disable*/
	PTCSE = 0x00; 		/*slew rate control*/
	PTCDS = 0x00;		  /*drive strength*/


	PTDD = 0x00;			/*PTD0--PTD7 are all available for JM60*/
  PTDDD = 0xFF;     /*Set output direction*/
	PTDPE = 0x00;		  /*Pull-up disable*/
	PTDSE = 0x00; 		/*slew rate control*/
	PTDDS = 0x00;		  /*drive strength*/

	PTED =  0x0C;			/*PTE0--PTE7 are all available for JM60*/
  PTEDD = 0xFF;     /*Set output direction*/
	PTEPE = 0x00;		  /*Pull-up disable*/
	PTESE = 0x00; 		/*slew rate control*/
	PTEDS = 0x00;		  /*drive strength*/

	PTFD = 0x43;			/*PTF0--PTF7 are all available for JM60*/
  PTFDD = 0xFF;     /*Set output direction*/
	PTFPE = 0x00;	  	/*Pull-up disable*/
	PTFSE = 0x00; 		/*slew rate control*/
	PTFDS = 0x00;		  /*drive strength*/

	PTGD = 0x00;			/*PTG6 & PTG7 are not available for JM60*/
  PTGDD = 0xF0;     /*PTG0-3 used for KBI input*/
	PTGPE = 0x0F;		  /*Pull-up disable    */
	PTGSE = 0x00; 		/*slew rate control*/
	PTGDS = 0x00;		  /*drive strength */
}


void MCG_Init()
{
	/* the MCG is default set to FEI mode, it should be change to FBE mode*/
	MCGC2 = 0x36;
		                  	/*  
                         *  0b01110100
                         *    ||||||||__ bit0:   EREFSTEN	Exernal reference stop enable
                         *    |||||||___ bit1:   ERCLKEN	External reference enable
                         *    ||||||____ bit2:   EREFS		External reference select
                         *    |||||_____ bit3:   LP			Low power select
                         *    ||||______ bit4:   HGO		High gain oscillator select
                         *    |||_______ bit5:   Range		Frequency range select
                         *    ||________ bit6:   BDIV		Bus frequency divider	
                         *    |_________ bit7:   BDIV	
                         */
                         
	while(!(MCGSC & 0x02));		/*ait for the OSC stable*/
		                  	/*  
                         *  0b00000010
                         *    ||||||||__ bit0:   FTRIM		MCG fine trim
                         *    |||||||___ bit1:   OSCINIT	OSC initialization
                         *    ||||||____ bit2:   CLKST		Clock Mode status
                         *    |||||_____ bit3:   CLKST
                         *    ||||______ bit4:   IREFST		Internal reference status
                         *    |||_______ bit5:   PLLST		PLL select status
                         *    ||________ bit6:   LOCK		Lock Status
                         *    |_________ bit7:   LOLS		Loss of lock status
                         */
                         
	MCGC1 = 0x9B;
		                    /*  
                         *  0b10110000
                         *    ||||||||__ bit0:   IREFSTEN	Internal reference stop enable
                         *    |||||||___ bit1:   IRCLKEN	Internal reference clock enable		
                         *    ||||||____ bit2:   IREFS		Internal reference select
                         *    |||||_____ bit3:   RDIV		Reference divider
                         *    ||||______ bit4:   RDIV
                         *    |||_______ bit5:   RDIv
                         *    ||________ bit6:   CLKS		Clock source select
                         *    |_________ bit7:   CLKS
                         */
	
	while((MCGSC & 0x1C ) != 0x08);		/* check the external reference clock is selected or not*/
	
	/* Switch to PBE mode from FBE*/
	MCGC3 = 0x48;
			/*  
                         *  0b01000110
                         *    ||||||||__ bit0:   VDIV		VCO divider
                         *    |||||||___ bit1:   VDIV
                         *    ||||||____ bit2:   VDIV
                         *    |||||_____ bit3:   VDIV
                         *    ||||______ bit4:   0
                         *    |||_______ bit5:   CME		Clock Monitor Enable
                         *    ||________ bit6:   PLLS 		PLL select
                         *    |_________ bit7:   LOLIE		Loss of lock interrupt enable
                         */
	while ((MCGSC & 0x48) != 0x48);		/*wait for the PLL is locked & */

	/*Switch to PEE mode from PBE mode*/
	MCGC1 &= 0x3F;
	while((MCGSC & 0x6C) != 0x6C);

	return;
}

