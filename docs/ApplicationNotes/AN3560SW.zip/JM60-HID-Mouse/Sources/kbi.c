/*************************************************************************
 * DISCLAIMER *
 * Services performed by FREESCALE in this matter are performed          *
 * AS IS and without any warranty. CUSTOMER retains the final decision   *
 * relative to the total design and functionality of the end product.    *
 * FREESCALE neither guarantees nor will be held liable by CUSTOMER      *
 * for the success of this project. FREESCALE disclaims all warranties,  *
 * express, implied or statutory including, but not limited to,          *
 * implied warranty of merchantability or fitness for a particular       *
 * purpose on any hardware, software ore advise supplied to the project  *
 * by FREESCALE, and or any product resulting from FREESCALE services.   *
 * In no event shall FREESCALE be liable for incidental or consequential *
 * damages arising out of this agreement. CUSTOMER agrees to hold        *
 * FREESCALE harmless against any and all claims demands or actions      *
 * by anyone on account of any damage, or injury, whether commercial,    *
 * contractual, or tortuous, rising directly or indirectly as a result   *
 * of the advise or assistance supplied CUSTOMER in connection with      *
 * product, services or goods supplied under this Agreement.             *
 *************************************************************************/
/*************************************************************************************************
 * File name   : Kbi.c
 *
 * Description : This file defines the routines for KBI, which is used for mouse buttons
 *               
 *
 * History     :
 * 04/01/07  : Initial Development
 * 
 *************************************************************************************************/
#include <MC9S08JM60.h>
#include "kbi.h"


/*Global variable definition*/
unsigned char Kbi_Stat = 0x00;

/*Global function definition*/
void Kbi_Init(void);



/******************************************************************************
 * Function:        void Kbi_Init(void)
 *
 * OverView:        This routine is the initialization function
 * Input:           None
 *
 * Output:          None
 *
 * Side Effects:    None
 * Note:            None
 *****************************************************************************/
void Kbi_Init(void)
{
   PTGDD &= 0xF0;     /*set PTG0-3 to input*/
   PTGPE |= 0x0F;     /*enable PTG0-3 pull-up resistor*/
   
   KBISC_KBACK = 1;
   KBIES = 0x00;
   KBIPE = 0xC3;      /*enable KBI0,1,6,7*/
   return;
}


/******************************************************************************
 * Function:        void Kbi_ISR(void)
 * Overview:        The routine is the KBI interrupt service routine
 * Input:           None
 *
 * Output:          None
 *
 * Side Effects:    None
 * Note:            None
 *****************************************************************************/
void interrupt 25 Kbi_ISR(void)
{
     Kbi_Stat = ~(PTGD & 0x0F);
     KBISC_KBACK = 1;
     return;
}





