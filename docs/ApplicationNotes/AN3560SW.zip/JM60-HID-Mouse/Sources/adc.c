/*************************************************************************
 * DISCLAIMER *
 * Services performed by FREESCALE in this matter are performed          *
 * AS IS and without any warranty. CUSTOMER retains the final decision   *
 * relative to the total design and functionality of the end product.    *
 * FREESCALE neither guarantees nor will be held liable by CUSTOMER      *
 * for the success of this project. FREESCALE disclaims all warranties,  *
 * express, implied or statutory including, but not limited to,          *
 * implied warranty of merchantability or fitness for a particular       *
 * purpose on any hardware, software ore advise supplied to the project  *
 * by FREESCALE, and or any product resulting from FREESCALE services.   *
 * In no event shall FREESCALE be liable for incidental or consequential *
 * damages arising out of this agreement. CUSTOMER agrees to hold        *
 * FREESCALE harmless against any and all claims demands or actions      *
 * by anyone on account of any damage, or injury, whether commercial,    *
 * contractual, or tortuous, rising directly or indirectly as a result   *
 * of the advise or assistance supplied CUSTOMER in connection with      *
 * product, services or goods supplied under this Agreement.             *
 *************************************************************************/
/*************************************************************************************************
 * File name   : Adc.c
 * Description : This software defines the routines for ADC
 *               The ADC module is used to sample the potentiomemter on demo board
 *               which is used to control the mouse shift direction 
 *
 * History     :
 * 04/01/07  : Initial Development
 * 
 *************************************************************************************************/
#include <MC9S08JM60.h>
#include "adc.h"

/* global variable definition*/
unsigned char HiAdcResult;
unsigned char LowAdcResult;
unsigned char CovEndFlag;
unsigned char Channel = 0;

/* globe function definition*/
void ADC_Init(void);
void ADC_Cvt(unsigned char Channel);


/**********************************************************************************************
 * ADC_Init: This function initilizes the ADC module
 *
 * Parameters:      none
 *
 * Subfunctions:    none.
 *
 * Return:          void
 *********************************************************************************************/ 
void ADC_Init(void)
{
     ADCCFG = 0x61;     /*busclk/2, Div by 8,ADCK = 1.5MHz*/
                        /*  0b0000000 0
                         *    ||||||| |__ bit0,1: ADICLK : input clock select   
                         *    |||||||_|
                         *    ||||||_____ bit2,3: MODE :  Conversion Mode selection
                         *    |||||_|  
                         *    ||||______ bit4:    ADLSMP: long sample time configuration
                         *    |||_______ bit5,6 : ADIV:   Clock Divide Select 
                         *    ||______| 
                         *    |_________ bit7:    ADLPC:  Low power configuration 
                         */
     
     ADCSC2 = 0x00;  
                        /*  0b00000000
                         *    ||||||||__ bit0:   
                         *    |||||||___ bit1: 
                         *    ||||||____ bit2: 
                         *    |||||_____ bit3: 
                         *    ||||______ bit4: ACFGT: Compare function greater than enable
                         *    |||_______ bit5: ACFE : Compare enable
                         *    ||________ bit6: ADTRG: Conversion trigger select
                         *    |_________ bit7: ADACT: Convert active
                         */

  	 #ifdef TENBIT_MODE
      ADCCFG |= 0x08;
     #endif
     
     #ifdef TWELVEBIT_MODE
       ADCCFG |= 0x04;
     #endif
   
    /*Change the channel, to check the releation between pins and channels */
    APCTL1 = 0xFF;   /*disable all ADC ports*/
    APCTL2 = 0x0F;
       
}



/****************************************************************************************
 * ADC_Cvt :  start to conversion of one channel
 * input:     channel is the channel number which will do conversion
 *
 * Return : None
 ***************************************************************************************/ 

void ADC_Cvt(unsigned char Channel) 
{
      #ifdef  ADC_INT_EN
          ADCSC1 = (Channel & 0x1F) | 0x40;   /*start the single conversion by software*/
      #else
          ADCSC1 = (Channel & 0x1F) ;         /*start the single conversion by software*/
      #endif
       
      #ifdef ADC_POLLING
          ADC_Poll();
      #endif

}

/****************************************************************************************
 * ADCISR: The ADC interrupt service routine that reads the ADC data register and places
 *         the value into global variables resulth and resultl
 *
 * Parameters: None
 *
 * Return : None
 ***************************************************************************************/ 
void ADC_Poll(void) 
{
  while(!ADCSC1_COCO);
  
  HiAdcResult = ADCRH;
  LowAdcResult = ADCRL;
  CovEndFlag = 1;
  
  return;
}

/****************************************************************************************
 * ADCISR: The ADC interrupt service routine which reads the ADC data register and places
 *         the value into global variables resulth and resultl
 *
 * Parameters: None
 *
 * Return : None
 ***************************************************************************************/ 
 interrupt 26 void ADCISR (void)
 {
    HiAdcResult = ADCRH;
    LowAdcResult = ADCRL;
    
    CovEndFlag = 1;
    
    return;
 }
