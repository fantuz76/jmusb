/*************************************************************************************************
 * Copyright (c) 2007, Freescale Semiconductor
 * Freescale Application Note
 *
 * File name   : main.c
 * Project name: JM60 Evaluation code
 *
 * Description : This software is the demo code for Application Note 3564
 *
 * History     :
 * 09/01/2007  : Initial Development
 * 11/14/2007  : Final Tests
 * 
 *************************************************************************************************/
#include <hidef.h>            /* for EnableInterrupts macro */
#include "derivative.h"       /* include peripheral declarations */
#include "Usb_Drv.h" 
#include "Usb_Config.h"
#include "S08_SPI.h"
#include "uart.h"
#include "IICV1Driver.h"
#include "FSLTypes_File.h"
#include "bridge.h"
#include "MCU.h"              /* MCU Initialization */
#include "USB_User_API.h"     /* USB API for USB Module */
#include "protocol_handler.h"


UINT8 buffer[3]={'a','B','c'};

/* Prototypes */ 
void Init_Sys(void);

void SlaveSPIInit(void)
{
  SPI1C1 = 0xFF;
  SPI1C2 = 0x10;
  SPI1BR = 0x21;
  SPI1C1_MSTR = 0;
  SPIRxPointer = &gaSPIRxBridgeBuffer[0];
}

void main(void) 
{
  /* System Initalization */
  Init_Sys();               
  //SlaveSPIInit();
  /* Enable Interrupts Macro */
  EnableInterrupts; 
  
  SendMsg(&buffer[0], 3);
  SPISendMessage(&buffer[0], 3);
  for(;;) 
  {    
    Check_USBBus_Status();
    vfnapIICV1Driver[gu8IICV1ActualState]();
    vfnBridge_Task();
    vfnProtocol_Handler_Task();
  } 
}

/*****************************************************************************
 * Init_Sys: Initialize the system
 * Input: 	None
 * Output: None
 * Parameters: None
 *
 ****************************************************************************/
void Init_Sys(void)
{
	Mcu_Init();               /* MCU general Initialization */
	MCG_Init();	              /* Initialize the MCG module to generate 24MHz bus clock */
  
	Initialize_USBModule();   /* Initialize USB Module */
	SPIInit();
	vfnIICV1Init();
	SCI1Init();
}
