/**
Copyright (c) 2006 Freescale Semiconductor
Freescale Confidential Proprietary
\file     bridge.h
\brief    Header for bridge.c
\author   Freescale Semiconductor
\author   Guadalajara Applications Laboratory RTAC Americas
\author   Eduardo Viramontes
\version  0.1
\date     02/Aug/2007
\warning  
* History:

  02/Aug/2007 Start of bridge coding.
  
*/
#ifndef _BRIDGE_H
#define _BRIDGE_H

#include "FSLTypes_File.h"
#include "S08_SPI.h"
#include "USB_User_API.h"   /* USB API for USB Module */
#include "protocol_handler.h"
#include "uart.h"

/* Defines */

#define BRIDGE_RX_BUFFER_SIZE         (8)
#define BRIDGE_TX_BUFFER_SIZE         (8)
/** This defines the start of raw data in the buffer */
#define BRIDGE_PROTOCOL_DATA_OFFSET   (2)
/** This defines the number of raw data bytes available in one buffer transmision (the buffer size
    minus the protocol overhead   */
#define BRIDGE_DATA_TX_SIZE           (BRIDGE_TX_BUFFER_SIZE-BRIDGE_PROTOCOL_DATA_OFFSET)
/** This defines the number of raw data bytes available in one buffer reception (the buffer size
    minus the protocol overhead   */
#define BRIDGE_DATA_RX_SIZE           (BRIDGE_RX_BUFFER_SIZE-BRIDGE_PROTOCOL_DATA_OFFSET)

#define SPI_BRIDGE_RX_SIZE            (3)
#define SCI_BRIDGE_RX_SIZE            (UART_BUFFER_SIZE)
#define IIC_BRIDGE_RX_SIZE            (3)

#define SCI_RX_RDY                    Rec_Frame_Flag
#define IIC_RX_RDY                    0

/* Function Prototypes */
void vfnBridge_Task(void);


#endif /* _FILENAME_H */
