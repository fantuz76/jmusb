/*************************************************************************************************
 * Copyright (c) 2007, Freescale Semiconductor
 * Freescale Application Note
 *
 * File name   : uart.h
 * Project name: JM60 Evaluation code
 *
 * Author      : Derek Liu
 * Department  : 8-bit Systems and Apps (Shanghai)
 *
 * Description : This software evaluates JM60 USB module 
 *               
 *
 * History     :
 * 01/29/07  : Initial Development
 * 
 *************************************************************************************************/

#ifndef _UART_H
#define _UART_H

#include "derivative.h"

#define UART_INT_EN   //use the interrupt for UART, currently it is only support interrupt

#define UART_BUFFER_SIZE  3
#define SCI_END_CHAR    0xFF

 
//#define PARITY_EN				 // Parity error check with Hyperterminal
//#derine ODD_PARITY
//#define EVEN_PARITY
//#define DATA9          // 9 data bits


typedef struct _UART_BUF 
{
   byte Buffer[UART_BUFFER_SIZE];
   byte Valid_Len;
}UART_BUF;

extern unsigned char Rec_Frame_Flag;
extern unsigned char Send_Busy;


extern void SCI1Init(void); 
extern unsigned char SendMsg(char msg[], char lenght);
extern unsigned char ReceiveMsg(char msg[]);

#endif