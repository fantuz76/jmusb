/**
  Copyright (c) 2007 Freescale Semiconductor
  Freescale Confidential Proprietary
  \file     	bridge.c
  \brief    	Functions for the USB bridge tasks
  \author   	Freescale Semiconductor
  \author     Eduardo Viramontes
  \author   	Guadalajara Applications Laboratory RTAC Americas
  \version    0.1
  \date     	02/August/2007
  \warning    (If needed)

  * History:
  
  02/Aug/2007  Start of bridge coding
  
*/
#include "bridge.h"


/**
 * \brief   This function is the main bridge task, checks for command inputs, runs the command
            decoder state machine and transfer and receive functions.
 * \author  Eduardo Viramontes
 * \param   None
 * \return  None
 * \todo    
 * \warning
 */
void vfnBridge_Task(void)
{
  UINT8 i;

  if(u8SPIRxCounter==SPI_BRIDGE_RX_SIZE)
  {
    gaDataRxBuffer[0] = SPI_ADDRESS;

    /* Empaquetar en una funci�n como la de SCI */
    for (i = 1; i <= SPI_BRIDGE_RX_SIZE; i++)
   	    gaDataRxBuffer[i] = gaSPIRxBridgeBuffer[i];
   	u8SPIRxCounter=0;
    SPIRxPointer-=BRIDGE_TX_BUFFER_SIZE;
   	/*********************************************/
   	
   	EndPoint_IN(EP4,SPI_BRIDGE_RX_SIZE);
  }
  else if(SCI_RX_RDY)
  {
    gaDataRxBuffer[0] = SCI_ADDRESS;
    ReceiveMsg(&gaDataRxBuffer[1]);
    EndPoint_IN(EP4,SCI_BRIDGE_RX_SIZE);
  }
  else if(IIC_RX_RDY)
  {
    gaDataRxBuffer[0] = IIC_ADDRESS;
    //ReceiveMsg(gaDataRxBuffer[1]);
    EndPoint_IN(EP4,IIC_BRIDGE_RX_SIZE);
  }

}

