

#include "protocol_handler.h"



/**
* \brief    Bridge commands function pointers array
* \author   Eduardo Viramontes
* \param    None
* \return   None
* \todo     
* \warning
*/
#pragma INTO_ROM
void (*const vfnpaProtocolCommands[MAX_NUMBER_PERIPH][MAX_NUMBER_COMMANDS])(void)=
{
/* MCU configuration commands */
  { 
    vfnDummyCommand,
    vfnDummyCommand,
    vfnDummyCommand,
    vfnDummyCommand,
    vfnDummyCommand,
    vfnDummyCommand,
    vfnDummyCommand,
    vfnDummyCommand
  },
  /* Boot loader commands */
  { 
    vfnDummyCommand,
    vfnDummyCommand,
    vfnDummyCommand,
    vfnDummyCommand,
    vfnDummyCommand,
    vfnDummyCommand,
    vfnDummyCommand,
    vfnDummyCommand
  },
  /* ADC commands */
  { 
    vfnDummyCommand,
    vfnDummyCommand,
    vfnDummyCommand,
    vfnDummyCommand,
    vfnDummyCommand,
    vfnDummyCommand,
    vfnDummyCommand,
    vfnDummyCommand
  },
  /* SPI commands */
  { 
    vfnSPIDataTx,
    vfnSPIBaudRateConfig,
    vfnSPI8or16BitConfig,
    vfnSPIMasterSlaveConfig,
    vfnSPIFullHalfDuplexConfig,
    vfnSPIClockPhaseConfig,
    vfnSPIClockPolarity,
    vfnSPIShifterDirection
  },
  { /* IIC Commands */
    vfnIICDataTx,
    vfnIICBaudRateConfig,
    vfnIICMasterSlaveConfig,
    vfnIICSlaveAddressConfig,
    vfnDummyCommand,
    vfnDummyCommand,
    vfnDummyCommand,
    vfnDummyCommand
  },
  { /* SCI commands */
    vfnSCIDataTx,
    vfnSCIBaudRateConfig,
    vfnSCIParityConfig,
    vfnDummyCommand,
    vfnDummyCommand,
    vfnDummyCommand,
    vfnDummyCommand,
    vfnDummyCommand
  },
  { /* GPIO Commands */
    vfnDummyCommand,
    vfnDummyCommand,
    vfnDummyCommand,
    vfnDummyCommand,
    vfnDummyCommand,
    vfnDummyCommand,
    vfnDummyCommand,
    vfnDummyCommand
  },
  { /* TPM commands */
    vfnDummyCommand,
    vfnDummyCommand,
    vfnDummyCommand,
    vfnDummyCommand,
    vfnDummyCommand,
    vfnDummyCommand,
    vfnDummyCommand,
    vfnDummyCommand
  },
};

/**
* \brief    Bridge data transfer function pointers array
* \author   Eduardo Viramontes
* \param    None
* \return   None
* \todo     
* \warning
*/
#pragma INTO_ROM
void (*const vfnpaProtocolDataTx[MAX_NUMBER_PERIPH])(void)=
{
  vfnDummyCommand,
  vfnDummyCommand,
  vfnDummyCommand,
  vfnSPIDataTx,
  vfnIICDataTx,
  vfnSCIDataTx,
  vfnDummyCommand,
  vfnDummyCommand
};

/**
 * \brief   This function is the main bridge task, checks for command inputs, runs the command
            decoder state machine and transfer and receive functions.
 * \author  Eduardo Viramontes
 * \param   None
 * \return  None
 * \todo    
 * \warning
 */
void vfnProtocol_Handler_Task(void)
{
  void (* vfnpCommandToExecute) (void);
//  UINT8 u8Counter;
    
  if(CHECK_COMMAND_ENDPOINT)    
  {
    vfnpCommandToExecute = vfnpaProtocolCommands[(gaProtocolCommandBuffer[PERIPH_ADDRESS_INDEX])]
                              [gaProtocolCommandBuffer[CONFIG_COMMAND_INDEX]];
    vfnpCommandToExecute();
  }
  else if(CHECK_DATA_ENDPOINT)
  {
    /*for (u8Counter = 0; u8Counter < 32; u8Counter++)
   	         EP4_Buffer[u8Counter] = EP3_Buffer[u8Counter];
    
    EndPoint_IN(EP4,32);*/
    vfnpCommandToExecute = vfnpaProtocolDataTx[(gaDataTxBuffer[PERIPH_ADDRESS_INDEX])];
    vfnpCommandToExecute();
  }
  
}

/**
 * \brief   Function used to fill up any unused commands in the function pointer arrays
 * \author  Eduardo Viramontes
 * \param   None
 * \return  None
 * \todo    
 * \warning
 */
void vfnDummyCommand(void)
{
  asm nop;
}

/**
 * \brief   Transfers received USB buffer to the SPI peripheral
 * \author  Eduardo Viramontes
 * \param   None
 * \return  None
 * \todo    
 * \warning
 */
void vfnSPIDataTx(void)
{
  SPISendMessage(&gaDataTxBuffer[DATA_TRANSFER_INDEX], PROTOCOL_DATATX_SIZE);
}

/**
 * \brief   Transfers received USB buffer to the SPI peripheral
 * \author  Eduardo Viramontes
 * \param   None
 * \return  None
 * \todo    
 * \warning
 */
void vfnIICDataTx(void)
{
  SPISendMessage(&gaDataTxBuffer[DATA_TRANSFER_INDEX], PROTOCOL_DATATX_SIZE);
}

/**
 * \brief   Transfers received USB buffer to the SPI peripheral
 * \author  Eduardo Viramontes
 * \param   None
 * \return  None
 * \todo    
 * \warning
 */
void vfnSCIDataTx(void)
{
  SendMsg(&gaDataTxBuffer[DATA_TRANSFER_INDEX], PROTOCOL_DATATX_SIZE);
}


void vfnSPIBaudRateConfig(void)
{
  SPI1BR_SPR = 1;
  SPI1BR_SPPR = 2;
  gaProtocolStatusBuffer[0] = SPI_ADDRESS;
  gaProtocolStatusBuffer[1] = SPI_BAUDRATE_CONFIG;
  gaProtocolStatusBuffer[2] = PROTOCOL_ACK;
  PROTOCOL_STATUS_TO_HOST;
}

void vfnSPI8or16BitConfig(void)
{
  SPI1C2_SPIMODE = 0;
  if(gaProtocolCommandBuffer[2])
  {
    SPI1C2_SPIMODE = 1;
  }
  gaProtocolStatusBuffer[0] = SPI_ADDRESS;
  gaProtocolStatusBuffer[1] = SPI_8or16BIT_CONFIG;
  gaProtocolStatusBuffer[2] = PROTOCOL_ACK;
  PROTOCOL_STATUS_TO_HOST;
}

void vfnSPIMasterSlaveConfig(void)  //CAREFUL! I changed this configuration for comaptibility with MCU reg
{
  SPI1C1_MSTR = 0;
  if(gaProtocolCommandBuffer[2])
  {
    SPI1C1_MSTR = 1;
  }
  gaProtocolStatusBuffer[0] = SPI_ADDRESS;
  gaProtocolStatusBuffer[1] = SPI_MASTERSLAVE_CONFIG;
  gaProtocolStatusBuffer[2] = PROTOCOL_ACK;
  PROTOCOL_STATUS_TO_HOST;
}

void vfnSPIFullHalfDuplexConfig(void)
{
  SPI1C2_SPC0 = 0;
  if(gaProtocolCommandBuffer[2])
  {
    SPI1C2_SPC0 = 1;
  }
  gaProtocolStatusBuffer[0] = SPI_ADDRESS;
  gaProtocolStatusBuffer[1] = SPI_FULLHALFDUPLEX_CONFIG;
  gaProtocolStatusBuffer[2] = PROTOCOL_ACK;
  PROTOCOL_STATUS_TO_HOST;
}

void vfnSPIClockPhaseConfig(void)
{
  SPI1C1_CPHA = 0;
  if(gaProtocolCommandBuffer[2])
  {
    SPI1C1_CPHA = 1;
  }
  gaProtocolStatusBuffer[0] = SPI_ADDRESS;
  gaProtocolStatusBuffer[1] = SPI_CLOCKPHASE_CONFIG;
  gaProtocolStatusBuffer[2] = PROTOCOL_ACK;
  PROTOCOL_STATUS_TO_HOST;
}

void vfnSPIClockPolarity(void)
{
  SPI1C1_CPOL = 0;
  if(gaProtocolCommandBuffer[2])
  {
    SPI1C1_CPOL = 1;
  }
  gaProtocolStatusBuffer[0] = SPI_ADDRESS;
  gaProtocolStatusBuffer[1] = SPI_CLOCKPOLARITY_CONFIG;
  gaProtocolStatusBuffer[2] = PROTOCOL_ACK;
  PROTOCOL_STATUS_TO_HOST;
}

void vfnSPIShifterDirection(void)
{
  SPI1C1_LSBFE = 0;
  if(gaProtocolCommandBuffer[2])
  {
    SPI1C1_LSBFE = 1;
  }
  gaProtocolStatusBuffer[0] = SPI_ADDRESS;
  gaProtocolStatusBuffer[1] = SPI_SHIFTERDIR_CONFIG;
  gaProtocolStatusBuffer[2] = PROTOCOL_ACK;
  PROTOCOL_STATUS_TO_HOST;
}

void vfnIICBaudRateConfig(void)
{
  IICF_MULT = (gaProtocolCommandBuffer[2]&0x03);
  IICF_ICR = gaProtocolCommandBuffer[3];
  gaProtocolStatusBuffer[0] = IIC_ADDRESS;
  gaProtocolStatusBuffer[1] = IIC_BAUDRATE_CONFIG;
  gaProtocolStatusBuffer[2] = PROTOCOL_ACK;
  PROTOCOL_STATUS_TO_HOST;
}

void vfnIICMasterSlaveConfig(void)
{
  IICC1_MST = 0;
  if(gaProtocolCommandBuffer[2]) 
  {
    IICC1_MST = 1;
  }
  gaProtocolStatusBuffer[0] = IIC_ADDRESS;
  gaProtocolStatusBuffer[1] = IIC_MASTERSLAVE_CONFIG;
  gaProtocolStatusBuffer[2] = PROTOCOL_ACK;
  PROTOCOL_STATUS_TO_HOST;
}

void vfnIICSlaveAddressConfig(void)
{
  IICA = (gaProtocolCommandBuffer[3]<<1);
  if(gaProtocolCommandBuffer[2]) 
  {
    IICC2_AD = gaProtocolCommandBuffer[4];
  }
  gaProtocolStatusBuffer[0] = IIC_ADDRESS;
  gaProtocolStatusBuffer[1] = IIC_SLAVEADDRESS_CONFIG;
  gaProtocolStatusBuffer[2] = PROTOCOL_ACK;
  PROTOCOL_STATUS_TO_HOST;
}

void vfnSCIBaudRateConfig(void)
{

  SCI1BDH = gaProtocolCommandBuffer[2];
  SCI1BDL = gaProtocolCommandBuffer[3];

  gaProtocolStatusBuffer[0] = SCI_ADDRESS;
  gaProtocolStatusBuffer[1] = SCI_BAUDRATE_CONFIG;
  gaProtocolStatusBuffer[2] = PROTOCOL_ACK;
  PROTOCOL_STATUS_TO_HOST;
}

void vfnSCIParityConfig(void)
{
  switch(gaProtocolCommandBuffer[2]) 
  {
    case 0:
      SCI1C1_PE = 0;
      break;  

    case 1:
      SCI1C1 |= 0x10;    // for 9 bit mode
    	SCI1C3_R8 = 1;    //for 9-bit mode
  	  SCI1C3_T8 = 1;
  	  SCI1C1_PT = 1;
      break;  
      
    case 2:
      SCI1C1 |= 0x10;    // for 9 bit mode
    	SCI1C3_R8 = 1;    //for 9-bit mode
  	  SCI1C3_T8 = 1;
  	  SCI1C1_PT = 0;
      break;
  }
  
  gaProtocolStatusBuffer[0] = SCI_ADDRESS;
  gaProtocolStatusBuffer[1] = SCI_PARITY_CONFIG;
  gaProtocolStatusBuffer[2] = PROTOCOL_ACK;
  PROTOCOL_STATUS_TO_HOST;
}

