/**
  Copyright (c) 2006 Freescale Semiconductor
  Freescale Confidential Proprietary
  \file         I2CDvr.c	
  \brief    	Source code for the I2C driver. Uses a pointer to transmit and
                receive data through I2C commands.
                The code in I2CDvr could be placed inside the ISR if timing is
                an issue.
  \author   	Freescale Semiconductor
  \author       Antonio Ramos Salido Maurer
  \author       Rafael Peralez Peralta
  \author   	Guadalajara Applications Laboratory RTAC Americas
  \version      1
  \date     	1/Feb/2007
  \warning

  * History:
            31/Jan/2007
            - Deleted u8TempIICS
            - Deleted NEW_MESSAGE approach
            - Added pointer to modify memory "in the fly"
  * ToDo:
        + Add 16 bit logical address section
        + Add master section / or change name to I2CSlaveDvr...
        + More Macros could be defined to avoid using specific variable names
          in the source .c file.
*/
/*****************************************************************************/

#include "I2CDvr.h"

UINT16 u16AddressDecoder(UINT8 u8SoftAddress);

UINT8 u8I2CStatus = 0;
UINT8 *pu8I2CData;

/*****************************************************************************/

void I2CInit(void)
{
    /* Set Pointer to known Address */
    pu8I2CData = &gu8aRTCData[0];
    /* Configure I2C module */
    IICA = DEVICE_SLAVE_ADDRESS;
    IICC = (IICC_IICEN_MASK|IICC_IICIE_MASK);
}

/*****************************************************************************/

interrupt void I2CIsr(void)
{
    /* Arbitration Lost ? */
    if(IICS & IICS_ARBL_MASK)
    {
        IICS |= IICS_ARBL_MASK;
        return;
    }
    /* Handle Address */
    if(IICS & IICS_IAAS_MASK)
    {
        IICC_TX = IICS_SRW;
        u8I2CStatus |= (1<<I2C_AAS_FLAG);
    }

    /* Handle Byte */ 
    if(IICS & IICS_TCF_MASK)
    {
        if(IICC_TX) /* Slave Data Out */
        {                                    
            if(IICS& IICS_RXAK_MASK)
            {
                IICC |= IICC_TXAK_MASK;
                IICC_TX = 0;
                IICD;   /* Dummy Read */
                return;
            }
            /* Transmitt current pointer address */
            IICD = *pu8I2CData++;
        }
        else        /* Slave Data In */
        {
            /* Write data at current pointer address */
            IICC &= ~IICC_TXAK_MASK;
            *pu8I2CData++ = IICD;
        }
    }
    #ifdef SLAVE_INTERRUPT
    /* Slave Interrupt pin to get Master's Attention */
    I2C_SLAVE_ASSERT_INTERRUPT();
    #endif /* SLAVE_INTERRUPT */
    /* Clear Interrupt Flag */
    IICS |= IICS_IICIF_MASK;
}


/*****************************************************************************/
