/* Include Files */
#include "MCU.h"            /* Include MCU Header */

/*****************************************************************************/
void Mcu_Init()
{
    SOPT1= SOPT1_STOPE_MASK;
    SPMSC1=SPMSC1_LVWACK_MASK;
}

/*****************************************************************************/

#ifdef CRYSTAL_12MHZ    

  void MCG_Init()
  {
	    /* the MCG is default set to FEI mode, it should be change to FBE mode*/
	    MCGC2=MCGC2_RANGE_MASK|MCGC2_HGO_MASK|MCGC2_EREFS_MASK|MCGC2_ERCLKEN_MASK;
                         
	    while(!MCGSC_OSCINIT);

      MCGC1= MCGC1_CLKS1_MASK | MCGC1_RDIV1_MASK | MCGC1_RDIV0_MASK | 
            MCGC1_IRCLKEN_MASK | MCGC1_IREFSTEN_MASK;

	    while((MCGSC & 0x1C ) != 0x08);		// check the external reference clock is selected or not

	    /* Switch to PBE mode from FBE */

      MCGC3=MCGC3_PLLS_MASK | MCGC3_VDIV3_MASK;

	    while ((MCGSC & 0x48) != 0x48);		//wait for the PLL is locked & 

	    /* Switch to PEE mode from PBE mode */
	    MCGC1&= MCGC1_RDIV2_MASK | MCGC1_RDIV1_MASK | MCGC1_RDIV0_MASK | 
	            MCGC1_IREFS_MASK | MCGC1_IRCLKEN_MASK | MCGC1_IREFSTEN_MASK;
	        
	    while((MCGSC & 0x6C) != 0x6C);
  }
#endif

