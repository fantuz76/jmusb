/**
  Copyright (c) 2006 Freescale Semiconductor
  Freescale Confidential Proprietary
  \file         I2CDvr.h	
  \brief    	Header file for the I2C communications driver.
  \author   	Freescale Semiconductor
  \author       Antonio Ramos Salido Maurer
  \author   	Guadalajara Applications Laboratory RTAC Americas
  \version      0.1
  \date     	3/Nov/2006
  \warning

  * History:
  
*/
/*****************************************************************************/

#ifndef __I2CDvr
#define __I2CDvr

#include "FslTypes.h"
#include "derivative.h"
#include "GpioDvr.h"

#define     SLAVE_INTERRUPT
#define     EIGHT_BIT_LOGICAL_ADDRESS
#undef      SIXTEEN_BIT_LOGICAL_ADDRESS


#define     I2C_SHUTDOWN_BASE_ADDRESS               (0x20)
#define     I2C_SHUTDOWN_SIZE                       (0x01)

#define     I2C_RTCDATA_BASE_ADDRESS                (0x00)
#define     I2C_RTCDATA_SIZE                        (0x07)

#define     DEVICE_SLAVE_ADDRESS    (0x14)

#define     I2C_SLAVE_ASSERT_INTERRUPT()            (GPIO_I2C_IRQ_OFF())

typedef enum
{
  I2C_INTERRUPT_FLAG,
  I2C_AAS_FLAG,
  I2C_ADDRESS_BYTE_FLAG,
}_eI2CFlags;

extern UINT8 u8I2CStatus;
extern UINT8 gu8ShutdownRegister;
extern UINT8 gu8aRTCData[];

/**
 * \brief       This function contains the I2C communications state machine.
                This could be placed at the Interrupt function.
 * \author      Antonio Ramos Salido Maurer
 */  
void I2CDvr(void);

/**
 * \brief       Initialization of the I2C module as slave.
 * \author      Antonio Ramos Salido Maurer
 */  
void I2CInit(void);

/*****************************************************************************/

#endif  /* __I2CDvr */