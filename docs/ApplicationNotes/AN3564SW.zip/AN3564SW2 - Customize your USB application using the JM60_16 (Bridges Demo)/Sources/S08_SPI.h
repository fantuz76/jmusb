#ifndef __S08_SPI__
  #define __S08_SPI__

  #include "typedef.h"
  #include "derivative.h"
  
  #define SPI_SS_DDR      PTEDD
  #define SPI_SS_PORT     PTED
  #define SPI_SS_PIN      7

  #define SPI_ISR_VECTOR  5

  #define SPI_TX_BUSY  (SPI1C1 & 0x20)
  
  #define SPI_SET_TX_POINTER(x)           SPITxPointer = (UINT8*)(x)
  #define SPI_SET_RX_POINTER(x)           SPIRxPointer = (UINT8*)(x)
  #define SPI_CLEAR_RX_COUNTER()          u8SPIRxCounter = 0
  
  extern byte* SPITxPointer;
  extern byte* SPIRxPointer;
  extern byte u8SPIRxCounter;
  extern byte u8SPITxCounter;
  extern byte gaSPIRxBridgeBuffer[8];
  
  void SPIInit(void);
  void SPISendByte(byte Data);
  void SPISendMessage(byte* MessagePtr, byte Size);
  
  
#endif