#include "S08_SPI.h"

#pragma CONST_SEG DEFAULT
#pragma CODE_SEG DEFAULT
#pragma DATA_SEG DEFAULT


byte* SPITxPointer;
byte* SPIRxPointer;
byte u8SPIRxCounter=0;
byte u8SPITxCounter=0;
byte gaSPIRxBridgeBuffer[8];

void SPIInit(void)
{
  /* ### Init_SPI init code */
  /* SPI1C1: 
    SPIE=1,   Interrupt enable
    SPE=1,    SPI System enable
    SPTIE=1,  Transmit interrupt enable
    MSTR=1,   Master
    CPOL=1,   Active low SPI clock
    CPHA=1,   First edge on SPSCK occurs at the start of the first cycle of a data transfer
    SSOE=1,   Slave select output enable
    LSBFE=1,  Least significant bit first
   */
  SPI1C1 = 0xFF;
  /* SPI1C2: 
    MODFEN=1,  Slave select output  
    BIDIROE=0,
    SPISWAI=0,
    SPC0=0 
  */
  SPI1C2 = 0x10;
  /* SPI1BR: Baud rate = 1 mbps
  SPPR2=0,SPPR1=1,SPPR0=0, Baud rate preescaler = 3
  SPR2=0,SPR1=0,SPR0=1,    Baud rate divisor = 4
  */
  SPI1BR = 0x21;
  
  //SPI_SS_DDR |= (1<<SPI_SS_PIN);
  //SPI_SS_PORT |= (1<<SPI_SS_PIN);
  SPIRxPointer = &gaSPIRxBridgeBuffer[0];
}

void SPISendByte(byte Data)
{
  (void)SPI1S;
  //SPI_SS_PORT &= ~(1<<SPI_SS_PIN);
  SPI1D = Data;
  u8SPITxCounter = 0;
  SPI1C1 |= 0x20;
  
}

void SPISendMessage(byte* MessagePtr, byte Size)
{
  SPITxPointer = MessagePtr+1;
  u8SPITxCounter = Size;
  (void)SPI1S;
  //SPI_SS_PORT &= ~(1<<SPI_SS_PIN);
  SPI1D = *MessagePtr;
  SPI1C1 |= 0x20;
}

__interrupt SPI_ISR_VECTOR void isrVspi(void)
{
  /* Reception */
  if (SPI1S & 0x80)
  {
    *SPIRxPointer++ = SPI1D;
    u8SPIRxCounter++;
  }
  
  /* Transmission */
  if (SPI1S & 0x20)
  {
    if (u8SPITxCounter)
    {
      SPI1D = *SPITxPointer;
      SPITxPointer++;
      u8SPITxCounter--;
    }
    else
    {
      SPI1C1 &= ~0x20; /* Clear SPTIE Bit, Tx Interrupt Disabled*/
      //SPI_SS_PORT |= (1<<SPI_SS_PIN);
    }
  }
}
