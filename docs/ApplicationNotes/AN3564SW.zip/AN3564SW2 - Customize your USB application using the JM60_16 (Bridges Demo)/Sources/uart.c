/*************************************************************************************************
 * Copyright (c) 2007, Freescale Semiconductor
 * Freescale Application Note
 *
 * File name   : uart.c
 * Project name: JM60 Evaluation code
 *
 * Author      : Derek Liu
 * Department  : 8-bit Systems and Apps (Shanghai)
 *
 * Description : This software evaluates JM60 USB module 
 *               
 *
 * History     :
 * 01/29/07  : Initial Development
 * 
 *************************************************************************************************/
#include "uart.h"

/* Baud Rate Defines - selected in SCIInit function with SCIBaudInit call */
#define BUS24M2400B  0
#define BUS24M9600B  1
#define BUS24M19200B 2								
#define BUS24MMAXB   3
#define BUS24MMINB	 4

#define BUS8M2400B   5   
#define BUS8M9600B	 6
#define BUS8M19200B	 7
#define BUS8M38400B  8
#define BUS8M57600B  9
#define BUS8M115200B 10

#define BUS16KMAX		 11	/* Max baud rate at 16K bus freq */				 
#define BUS16KMIN	   12 /* Min baud rate at 16K bus freq */

/* Global Variables */
unsigned char Rec_Frame_Flag = 0;
unsigned char Send_Busy_Flag = 0;

/* Local Variables */
UART_BUF  Rec_Buf;
UART_BUF  Send_Buf;
unsigned char Send_Ptr = 0;


/* Function Parameters */
void SCI1Init(void); 
void SCI1BaudInit(char SCI_baud);

unsigned char SendMsg(char msg[], char lenght);
unsigned char ReceiveMsg(char msg[]);





 /******************************************************************************
 * SCIInit: This function sets up the SCI baud rate and mode.
 *
 * Parameters:      none
 *
 * Subfunctions:    none.
 *
 * Return:          void
 *******************************************************************************/ 

void SCI1Init(void)
 {

  /* -----CHANGE BAUD RATES HERE!---- */ 
   SCI1BaudInit(BUS24M9600B);   //Pick one of the baud rate defines from top of file
   
    SCI1C1 = 0x00;		/*  
                         *  0b00000000
                         *    ||||||||__ bit0: PT  
                         *    |||||||___ bit1: PE
                         *    ||||||____ bit2: ILT
                         *    |||||_____ bit3: WAKE
                         *    ||||______ bit4: M
                         *    |||_______ bit5: RSRC
                         *    ||________ bit6: SCISWAI
                         *    |_________ bit7: LOOPS
                         */
                         
    SCI1C2 = 0x0C;		/*  
                         *  0b00000000
                         *    ||||||||__ bit0: SBK  
                         *    |||||||___ bit1: RWU
                         *    ||||||____ bit2: RE
                         *    |||||_____ bit3: TE
                         *    ||||______ bit4: ILIE
                         *    |||_______ bit5: RIE
                         *    ||________ bit6: TCIE
                         *    |_________ bit7: TIE
                         */                      
 
 
    SCI1S2 = 0x00;		/*  
                         *  0b00000000
                         *    ||||||||__ bit0: RAF  
                         *    |||||||___ bit1: LBKDE
                         *    ||||||____ bit2: BRK13
                         *    |||||_____ bit3: RWUID
                         *    ||||______ bit4: RXINV
                         *    |||_______ bit5: 0
                         *    ||________ bit6: RXEDGIF
                         *    |_________ bit7: LBKDIF
                         */
  
  #ifdef DATA9
    SCI1C1 |= 0x10;          // for 9 bit mode
  	SCI1C3_R8 = 1;    //for 9-bit mode
	  SCI1C3_T8 = 1;
	#endif
  
   
  #ifdef PARITY_EN
      SCI1C1_PE = 1;         // enable parity
    #ifdef ODD_PARITY
      SCI1C1_PT = 1;         // odd polarity
    #else
      SCI1C1_PT = 0;
    #endif
  #endif
//      SCI1C3_PEIE = 1;
  PTED_PTED1 =1;
  PTED_PTED0 =1;
  SCI1C2_RE = 1;
  SCI1C2_TE = 1;
  
} 

/**********************************************************************************************
 * SCIBaudInit: This function selects the SCI baud rate for various tests
 *
 * Parameters:      Desired baud rate per bus clock setting
 *
 * Subfunctions:    none.
 *
 * Return:          void
 *********************************************************************************************/ 
void SCI1BaudInit(char SCI_baud)
{
    /*switch (SCI_baud) 
     {		// IF Switching between xtal and canned osc, MAKE CHANGES HERE
      case BUS24M2400B: SCI1BDH = 0x02; SCI1BDL = 0x8F; break; 
      case BUS24M9600B:	SCI1BDH = 0x00; SCI1BDL = 0xA4; break; 
      case BUS24M19200B:SCI1BDH = 0x00; SCI1BDL = 0x52; break;												
      case BUS24MMAXB:	SCI1BDH = 0x00; SCI1BDL = 0x01; break; 	//1572864 baud rate 
      case BUS24MMINB:	SCI1BDH = 0x1F; SCI1BDL = 0xFF; break;  //192 baud rate  
      case BUS8M2400B:  SCI1BDH = 0x00; SCI1BDL = 0xDA; break; 
      case BUS8M9600B	:	SCI1BDH = 0x00; SCI1BDL = 0x36; break; 
      case BUS8M19200B:	SCI1BDH = 0x00; SCI1BDL = 0x1B; break;
      case BUS8M38400B:	SCI1BDH = 0x00; SCI1BDL = 0x0E; break;   
      case BUS8M57600B:	SCI1BDH = 0x00; SCI1BDL = 0x09; break;      
      case BUS8M115200B:SCI1BDH = 0x00; SCI1BDL = 0x05; break; 
      case BUS16KMAX:		SCI1BDH = 0x00; SCI1BDL = 0x01; break; 	//1000 baud rate
      case BUS16KMIN:	  SCI1BDH = 0x1F; SCI1BDL = 0xFF; break; 	//3.92 baud rate
      default:          SCI1BDH = 0x00; SCI1BDL = 0x34; break;  //defaults to 9600 with 8 MHz bus

    }*/
    SCI1BDH = 0x00; 
    SCI1BDL = 0x9C;
    
}



/*************************************************************************************
 * SendMsg: This function sends a message through the SCI Tx pin. 
 *
 * Parameters:      character string to transmit
 *
 * Subfunctions:    none.
 *
 * Return:          void
 ************************************************************************************/ 
unsigned char SendMsg(char *msg, char lenght)
{
  byte dummy = 0x00;
  char *ptr = msg;
  
  if(Send_Busy_Flag)
    return 0;
  
  Send_Buf.Valid_Len = 0;
  
  while((Send_Buf.Valid_Len < lenght) && (*ptr != SCI_END_CHAR) )
  {
    Send_Buf.Buffer[Send_Buf.Valid_Len] = *ptr;
    ptr++;
    Send_Buf.Valid_Len ++;
  }
  
  Send_Ptr = 0;
  dummy = SCI1S1;
  SCI1D = Send_Buf.Buffer[Send_Ptr++];   // 2nd half of TDRE clear procedure 
  Send_Busy_Flag = 1;
  
  SCI1C2_TIE = 1;
  SCI1C2_TCIE = 1;
  
  return 1;
} 


/*************************************************************************************
 * SendMsg: This function sends a message through the SCI Tx pin. 
 *
 * Parameters:      character string to transmit
 *
 * Subfunctions:    none.
 *
 * Return:          void
 ************************************************************************************/ 
unsigned char ReceiveMsg(char msg[]) 
{
   char *ptr = msg;
   unsigned char i = 0;
   
   if(!Rec_Frame_Flag)
      return 0;
   
   while((i < Rec_Buf.Valid_Len))
     *(ptr + i) = Rec_Buf.Buffer[i];
     
   Rec_Frame_Flag = 0;
   Rec_Buf.Valid_Len = 0;
   return 1;
}




#ifdef UART_INT_EN
/**********************************************************************************
 * SCIError: This interrupt happens every time an SCI Error condition 
 *         flag is detected The interrupt routine sets PTA0 on parity error 
 *
 * Parameters:      none.
 *
 * Subfunctions:    none.
 *
 * Return:          void
 ***********************************************************************************/ 
void interrupt 19 SCI1Error (void)    //The interrupt vector number corresponds to SCI error interrupt vector (see datasheet)
{ 
    byte dummy;
    
     
    dummy = SCI1S1;  
    dummy = SCI1D;        // Load received data into a global variable 
    //PTAD_PTAD3 = !PTAD_PTAD3;   
}

 



/***********************************************************************************
 * SCI1RxIsr: This interrupt happens every time the SCI Receiver Full
 *         flag is detected, announcing the Rx pin received a character.
 *         The interrupt routine loads the data received and sends it back 
 *
 * Parameters:      none.
 *
 * Subfunctions:    none.
 *
 * Return:          void
 ***********************************************************************************/ 
void interrupt 20 SCI1RxIsr (void)
 {
    byte Chr;

		Chr = SCI1S1;
    Chr = SCI1D;   
    
    if(Rec_Frame_Flag) 
    {
      Rec_Buf.Valid_Len = 0;  //override the old frame despite it has not been read out
      Rec_Frame_Flag = 0;
    }
    
    if(Rec_Buf.Valid_Len < UART_BUFFER_SIZE)
      Rec_Buf.Buffer[Rec_Buf.Valid_Len] = Chr;
    
    Rec_Buf.Valid_Len ++;
    
    if((Rec_Buf.Valid_Len >= UART_BUFFER_SIZE) || (Chr == SCI_END_CHAR))
      Rec_Frame_Flag = 1;
      
    return;
}


/************************************************************************************
 * SCI1RxIsr: This interrupt happens every time the SCI Transmit Empty
 *         flag is detected, announcing the TX buffer is empty.
 *         The interrupt routine sends the character 'A' continuously. 
 *
 * Parameters:      none.
 *
 * Subfunctions:    none.
 *
 * Return:          void
 ***********************************************************************************/ 

void interrupt 21 SCI1TxIsr (void)
{
    byte Chr;
   
    Chr = SCI1S1;
    
    if(Send_Ptr < Send_Buf.Valid_Len)
      {
        SCI1D = Send_Buf.Buffer[Send_Ptr];
        Send_Ptr ++;
      }
    else
      {
         if(SCI1S1_TC)
          {
              Send_Busy_Flag = 0;;
              SCI1C2_TIE = 0;
              SCI1C2_TCIE = 0;
          }

      }
}

#endif