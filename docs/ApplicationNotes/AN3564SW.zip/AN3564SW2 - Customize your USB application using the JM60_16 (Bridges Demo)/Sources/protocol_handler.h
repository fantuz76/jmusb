/**
Copyright (c) 2007 Freescale Semiconductor
Freescale Confidential Proprietary
\file     protocol_handler.h
\brief    Header for protocol_handler.c
\author   Freescale Semiconductor
\author   Guadalajara Applications Laboratory RTAC Americas
\author   Eduardo Viramontes
\version  0.1
\date     01/Nov/2007
\warning  
* History:

  
*/

#ifndef _PROTOCOL_HANDLER_H
#define _PROTOCOL_HANDLER_H

#include "FSLTypes_File.h"
#include "USB_User_API.h"   /* USB API for USB Module */
#include "derivative.h"
#include "S08_SPI.h"
#include "uart.h"

/* Defines */

#define MAX_NUMBER_PERIPH   (8)
#define MAX_NUMBER_COMMANDS (8)

#define PROTOCOL_ACK  0xFF
#define PROTOCOL_NACK 0x00

typedef enum
{
  MCU_CONFIG_ADDRESS,
  BOOTLOADER_MODE_ADDRESS,
  ADC_ADDRESS,
  SPI_ADDRESS,
  IIC_ADDRESS,
  SCI_ADDRESS,
  GPIO_ADDRESS,
  TPM_ADDRESS
}__PROTOCOL_PERIPHERAL_ADDRESSES__;

typedef enum
{
  SPI_DATA_TX,
  SPI_BAUDRATE_CONFIG,
  SPI_8or16BIT_CONFIG,
  SPI_MASTERSLAVE_CONFIG,
  SPI_FULLHALFDUPLEX_CONFIG,
  SPI_CLOCKPHASE_CONFIG,
  SPI_CLOCKPOLARITY_CONFIG,
  SPI_SHIFTERDIR_CONFIG
}__PROTOCOL_SPI_COMMANDS__;

typedef enum
{
  IIC_DATA_TX,
  IIC_BAUDRATE_CONFIG,
  IIC_MASTERSLAVE_CONFIG,
  IIC_SLAVEADDRESS_CONFIG
}__PROTOCOL_IIC_COMMANDS__;

typedef enum
{
  SCI_DATA_TX,
  SCI_BAUDRATE_CONFIG,
  SCI_PARITY_CONFIG
}__PROTOCOL_SCI_COMMANDS__;


#define PERIPH_ADDRESS_INDEX  (0)
#define CONFIG_COMMAND_INDEX  (1)
#define CONFIG_DATA_INDEX     (2)
#define DATA_TRANSFER_INDEX   (1)

/** Endpoint buffer where commands are received */
#define gaProtocolCommandBuffer (EP1_Buffer)
#define PROTOCOL_COMMAND_EP     (EP1)
#define PROTOCOL_COMMAND_SIZE   (UEP1_SIZE)
/** Endpoint buffer where data is received from USB host and sent to peripherals */
#define gaDataTxBuffer          (EP3_Buffer)
#define PROTOCOL_DATATX_EP      (EP3)
#define PROTOCOL_DATATX_SIZE    (UEP3_SIZE)
/** Endpoint buffer where status is sent to host */
#define gaProtocolStatusBuffer  (EP2_Buffer)
#define PROTOCOL_STATUS_EP      (EP2)
#define PROTOCOL_STATUS_SIZE    (UEP2_SIZE)
/** Endpoint buffer where data is received from peripherals and sent to USB host */
#define gaDataRxBuffer          (EP4_Buffer)
#define PROTOCOL_DATARX_EP      (EP4)
#define PROTOCOL_DATARX_SIZE    (UEP4_SIZE)

#define CHECK_COMMAND_ENDPOINT    CheckEndPointOUT(PROTOCOL_COMMAND_EP)
#define CHECK_DATA_ENDPOINT       CheckEndPointOUT(PROTOCOL_DATATX_EP)
#define PROTOCOL_STATUS_TO_HOST   EndPoint_IN(PROTOCOL_STATUS_EP,PROTOCOL_STATUS_SIZE)
#define PERIPH_DATA_TO_HOST       EndPoint_IN(PROTOCOL_DATARX_EP,PROTOCOL_DATARX_SIZE)

/* Function Prototypes */

void vfnProtocol_Handler_Task(void);
void vfnIICDataTx(void);
void vfnSCIDataTx(void);

/* Command function prototypes */
void vfnDummyCommand(void);
void vfnSPIDataTx(void);
void vfnSPIBaudRateConfig(void);
void vfnSPI8or16BitConfig(void);
void vfnSPIMasterSlaveConfig(void);
void vfnSPIFullHalfDuplexConfig(void);
void vfnSPIClockPhaseConfig(void);
void vfnSPIClockPolarity(void);
void vfnSPIShifterDirection(void);
void vfnIICDataTx(void);
void vfnIICBaudRateConfig(void);
void vfnIICMasterSlaveConfig(void);
void vfnIICSlaveAddressConfig(void);
void vfnSCIDataTx(void);
void vfnSCIBaudRateConfig(void);
void vfnSCIParityConfig(void);


#endif /* _PROTOCOL_HANDLER_H */
