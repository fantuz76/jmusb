#ifndef _MCU_H
#define _MCU_H

/* Includes */
#include "derivative.h"     /* include peripheral declarations */

/* Definitions */
#define CRYSTAL_12MHZ       /* 12 MHz external crystal */


/* Prototypes */
void Mcu_Init(void);
void MCG_Init(void);


#endif /* _MCU_H */
