#include <hidef.h> /* for EnableInterrupts macro */
#include "derivative.h" /* include peripheral declarations */



const byte NVOPT_INIT  @0x0000FFBF = 0x02;    // vector redirect, flash unsecure
const byte NVPROT_INIT @0x0000FFBD = 0xFA;    // 0xFC00-0xFFFF are protected 

extern void _Startup(void);

interrupt void Dummy_ISR(void) {
  
}
 
 
void main(void) {
   
   TPM1MOD = 20000;
   TPM1SC = 0x4F;
   
   EnableInterrupts;
   
   for(;;) {
    
    __RESET_WATCHDOG();
   }
}


interrupt void TPM1Overflow_ISR(void) {
  
  (void)TPM1SC;
  TPM1SC_TOF = 0;
  PTED_PTED2 ^=1;         // PTE2 LED toggle
  
}


void (* volatile const _UserEntry[])()@0xFBBC={
  0x9DCC,             // asm NOP(9D), asm JMP(CC)
  _Startup
};
  
// redirect vector 0xFFC0-0xFFFD to 0xFBC0-0xFBFD
void (* volatile const _Usr_Vector[])()@0xFBC4= {
    Dummy_ISR,        // Int.no.29 RTC                (at FFC4)
    Dummy_ISR,        // Int.no.28 IIC                (at FFC6)
    Dummy_ISR,        // Int.no.27 ACMP               (at FFC8)
    Dummy_ISR,        // Int.no.26 ADC                (at FFCA)
    Dummy_ISR,        // Int.no.25 KBI                (at FFCC)
    Dummy_ISR,        // Int.no.24 SCI2 Transmit      (at FFCE)
    Dummy_ISR,        // Int.no.23 SCI2 Receive       (at FFD0)
    Dummy_ISR,        // Int.no.22 SCI2 Error         (at FFD2)
    Dummy_ISR,        // Int.no.21 SCI1 Transmit      (at FFD4)
    Dummy_ISR,        // Int.no.20 SCI1 Receive       (at FFD6)
    Dummy_ISR,        // Int.no.19 SCI1 error         (at FFD8)
    Dummy_ISR,        // Int.no.18 TPM2 Overflow      (at FFDA)
    Dummy_ISR,        // Int.no.17 TPM2 CH1           (at FFDC)
    Dummy_ISR,        // Int.no.16 TPM2 CH0           (at FFDE)
    TPM1Overflow_ISR, // Int.no.15 TPM1 Overflow      (at FFE0)
    Dummy_ISR,        // Int.no.14 TPM1 CH5           (at FFE2)
    Dummy_ISR,        // Int.no.13 TPM1 CH4           (at FFE4)
    Dummy_ISR,        // Int.no.12 TPM1 CH3           (at FFE6)
    Dummy_ISR,        // Int.no.11 TPM1 CH2           (at FFE8)
    Dummy_ISR,        // Int.no.10 TPM1 CH1           (at FFEA)
    Dummy_ISR,        // Int.no.9  TPM1 CH0           (at FFEC)
    Dummy_ISR,        // Int.no.8  Reserved           (at FFEE)
    Dummy_ISR,        // Int.no.7  USB Statue         (at FFF0)
    Dummy_ISR,        // Int.no.6  SPI2               (at FFF2)
    Dummy_ISR,        // Int.no.5  SPI1               (at FFF4)
    Dummy_ISR,        // Int.no.4  Loss of lock       (at FFF6)
    Dummy_ISR,        // Int.no.3  LVI                (at FFF8)
    Dummy_ISR,        // Int.no.2  IRQ                (at FFFA)
    Dummy_ISR,        // Int.no.1  SWI                (at FFFC) 
};



#pragma CODE_SEG Bootloader_ROM

void Bootloader_Main(void);

void _Entry(void) {

  byte i;
   
  PTGDD_PTGDD0 = 0;               // PTG0 is input
  PTGPE_PTGPE0 = 1;               // internal pullup for PTG0
  
  PTEDD_PTEDD2 = 1;               // PTE2 as output
  PTEDD_PTEDD3 = 1;               // PTE3 as output
  
  PTED_PTED2 = 1;
  PTED_PTED3 = 1;
  
  // delay some time for oscillator and GPIO stable
  for(i=0;i<50;i++) {
    
    __RESET_WATCHDOG();
  }
      
 


  // Mode selection  
  if(PTGD_PTGD0) {
    asm JMP _UserEntry;           // Enter User Mode
  } 
  
  // Enter Bootloader Mode
  else {
    
    
    // Step1: Disable COP
    SOPT1 = 0x20;                 
  
    
    // Step2: MCG clock initialization
    //        Configure bus clock to 24MHz with PEE mode
    //        Provide different configuration with different clock input
    
    
    /*
    // External 4MHz clock input
    MCGC2 = 0x36;
    while(!(MCGSC & 0x02));		      
    MCGC1 = 0x0A;
	  MCGC3 = 0x46;
	  while ((MCGSC & 0x48) != 0x48);
    */
    
    /*
     // External 8MHz clock input
    MCGC2 = 0x36;
    while(!(MCGSC & 0x02));		      
    MCGC1 = 0x12;
	  MCGC3 = 0x46;
	  while ((MCGSC & 0x48) != 0x48);
    */
    
    // JM60 demo board with 12MHz external clock input
    MCGC2 = 0x36;
    while(!(MCGSC & 0x02));		      //wait for the OSC stable
    MCGC1 = 0x1B;
	  MCGC3 = 0x48;
	  while ((MCGSC & 0x48) != 0x48);	//wait for the PLL is locked
	
	  
    // Step3: Initialize on-chip regulator and pullup resistor                                
    USBCTL0=0x44;
    
    PTED_PTED3 = 0;                 // PTE3 output0, JM60 demo board LED on                  
    
    Bootloader_Main();              // Enter bootloader code
   }

} // _Entry end













