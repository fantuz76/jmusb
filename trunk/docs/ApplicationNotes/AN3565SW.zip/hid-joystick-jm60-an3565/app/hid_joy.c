/****************************************************************************
 *
 *            Copyright (c) 2006-2007 by CMX Systems, Inc.
 *
 * This software is copyrighted by and is the sole property of
 * CMX.  All rights, title, ownership, or other interests
 * in the software remain the property of CMX.  This
 * software may only be used in accordance with the corresponding
 * license agreement.  Any unauthorized use, duplication, transmission,
 * distribution, or disclosure of this software is expressly forbidden.
 *
 * This Copyright notice may not be removed or modified without prior
 * written consent of CMX.
 *
 * CMX reserves the right to modify this software without notice.
 *
 * CMX Systems, Inc.
 * 12276 San Jose Blvd. #511
 * Jacksonville, FL 32223
 * USA
 *
 * Tel:  (904) 880-1840
 * Fax:  (904) 880-1632
 * http: www.cmx.com
 * email: cmx@cmx.com
 *
 ***************************************************************************/
#include "hid.h"
#include "hid_joy.h"
#include "target.h"
#include "adc.h"


#define USE_ACCEROMETER
#define USE_POTENTIOMETER

#define THROTTLE_THRESHOLD    1
#define XY_THRESHOLD          4

/****************************************************************************
 ************************** Macro definitions *******************************
 ***************************************************************************/
/* Class specific requests. */
#define HIDRQ_GET_REPORT    0x1
#define HIDRQ_GET_IDLE      0x2
#define HIDRQ_GET_PROTOCOL  0x3

#define HIDRQ_SET_REPORT    0x9
#define HIDRQ_SET_IDLE      0xa
#define HIDRQ_SET_PROTOCOL  0xb

/* Descriptor type values for HID descriptors. */
#define GHIDD_HID_DESCRIPTOR      0x21
#define GHIDD_REPORT_DESCRIPTOR   0x22
#define GHIDD_PHYSICAL_DESCRIPTOR 0x23

// Get the corresponding fields of the HID joystic report.
#define DIR_REP_THROTTLE(h) ((h)[0])
#define DIR_REP_BUTTONS(h)  ((h)[3])      /* upper 4 bits */
#define DIR_REP_HAT(h)      ((h)[3])
#define DIR_REP_X(h)	      ((h)[1])
#define DIR_REP_Y(h)        ((h)[2])
#define GET_RPT_IN_HAT(h)                 (DIR_REP_HAT(h) & 0x0f)

// Change the corresponding fields of the HID joystic report.
#define CHANGE_RPT_IN_X(h,x)              DIR_REP_X(h) = x
#define CHANGE_RPT_IN_Y(h,y)              DIR_REP_Y(h) = y
#define CHANGE_RPT_IN_THROTTLE(h,thrtl)   DIR_REP_THROTTLE(h) = thrtl
#define CHANGE_RPT_IN_HAT(h,hat)          DIR_REP_HAT(h) = (DIR_REP_HAT(h) & 0xf0) | (hat & 0x0f)

// Set the corresponding fields of the HID joystic report.
#define SET_RPT_IN_BUTTONS(h, btn)        DIR_REP_BUTTONS(h) |= (1<<(btn+3))
// Clear the corresponding fields of the HID joystic report.
#define CLEAR_RPT_IN_BUTTONS(h, btn)      DIR_REP_BUTTONS(h) &= ~(1<<(btn+3))



/****************************************************************************
 ************************** Function predefinitions. ************************
 ***************************************************************************/
#define busy_wait()

void joy_got_reset(void);
static hcc_u8 joy_scan_matrix(void);
void joy_start_mS_timer(hcc_u16 delay);



/****************************************************************************
 ************************** Global variables ********************************
 ***************************************************************************/
static hcc_u8 device_stp=0;

/****************************************************************************
 ************************** Module variables ********************************
 ***************************************************************************/
static signed char hid_joy_report_in[HID_JOY_REPORT_IN_SIZE] = {
  0};
  
static volatile hcc_u8 xy_state_changed = FALSE;
static volatile hcc_u8 hat_state_changed = FALSE;

#ifdef USE_ACCEROMETER
static unsigned char x = 0,y=0,throttle = 127,hat = -1;
#else
static signed char x = -127,y=-127,throttle = -127, south=TRUE,east =TRUE,accer=TRUE;
#endif

/****************************************************************************
 ************************** Function definitions ****************************
 ***************************************************************************/


/*****************************************************************************
 * USB callback function. Is called by the USB driver if an USB reset event
 * occuers.
 ****************************************************************************/
void joy_got_reset(void)
{
  /* do some initialisation. */
  DIR_REP_THROTTLE(hid_joy_report_in)=0;
  DIR_REP_BUTTONS(hid_joy_report_in)=0;
  DIR_REP_X(hid_joy_report_in)=0;
  DIR_REP_Y(hid_joy_report_in)=0;
}

/*****************************************************************************
 * This function will move the mouse pointer from left to right and back in
 * an endless loop.
 ****************************************************************************/
 
/****************************************************************************
 ************************** Function definitions ****************************
 ***************************************************************************/
/*****************************************************************************
 * Scan the key matrix, and add a scan code for each pressed key to the 
 * outpout report.
 ****************************************************************************/
static hcc_u8 joy_scan_matrix(void)
{
  int x=0;
  hcc_u8 r=0;

  if (SW1_ACTIVE())
  {
    r = BIT0;
    SET_RPT_IN_BUTTONS(hid_joy_report_in,JOY_BUTTON_1);    /* button 1 pressed */
  } else {
    r &= ~BIT0;
    CLEAR_RPT_IN_BUTTONS(hid_joy_report_in,JOY_BUTTON_1);  /* button 1 released */
  }
  if (SW2_ACTIVE())
  {
    r |=BIT1;
    SET_RPT_IN_BUTTONS(hid_joy_report_in,JOY_BUTTON_2);
  } else {
    r &= ~BIT1; 
    CLEAR_RPT_IN_BUTTONS(hid_joy_report_in,JOY_BUTTON_2);  
  }
  if (SW3_ACTIVE())
  {
    r |=BIT2;
    SET_RPT_IN_BUTTONS(hid_joy_report_in,JOY_BUTTON_3);
  } else {
    r &= ~BIT2; 
    CLEAR_RPT_IN_BUTTONS(hid_joy_report_in,JOY_BUTTON_3);  
  }  
  if (SW4_ACTIVE())
  {
    r |=BIT3;
    SET_RPT_IN_BUTTONS(hid_joy_report_in,JOY_BUTTON_4);
  } else {
    r &= ~BIT3; 
    CLEAR_RPT_IN_BUTTONS(hid_joy_report_in,JOY_BUTTON_4);  
  }  
  return(r);
}


int hid_joy(void)
{
  hcc_u8 in_report;
  hcc_u8 cur_state,last_state;
 
  /* Per requirement of Windows HID-compliant game controller,
   * Hat switch controls must report a Null value when not pressed. 
   * When pressed, the logical minimum value represents north, 
   * and increasing logical values represent directions equally spaced clockwise around the compass
   */
 
  CHANGE_RPT_IN_HAT(hid_joy_report_in,-1);  
  DIR_REP_X(hid_joy_report_in) = 0;
  DIR_REP_Y(hid_joy_report_in) = 0;
  DIR_REP_THROTTLE(hid_joy_report_in) = 127;
 
  /* Initialize the HID driver
   */
  HID_init(500, JOY_IFC_INDEX);
  
  /* Define a new report for the joystick
   */
  in_report=hid_add_report(rpt_in, 0, HID_JOY_REPORT_IN_SIZE);

#ifdef USE_ACCEROMETER  
  /* Initialize ADC. */
  ADC_Init();  
   /* Get initial X value with scaled result. 
    * AdcResult of 0xFFF --> X of 127, and 0 --> X of -127 */
   ADC_Cvt(3); 
   x = (AdcResult >>4);
   
   /* Get initial Y value with scaled result.
    */
   ADC_Cvt(0); 
   y = (AdcResult >>4);
   
   /* Get initial throttle value with scaled result.
    * throttle is corresponding Z output of accerometer.
    */
   ADC_Cvt(1); 
   throttle = (AdcResult >>4);  
   /*
    * Get hat value.
    */
   ADC_Cvt(9);
   hat = (AdcResult>>10);
#endif 
   
  /* Initialize the timer.
   */
  joy_start_mS_timer(100);
  
  while(!device_stp)
  {
    /* Handle the pending HID reports.
     */
    hid_process();
    
    
    /* Check if there is not any pending report.
     */
    if (!hid_report_pending(in_report))
    {     
      if(xy_state_changed) {        
        xy_state_changed = FALSE;
      
        /* Write report data.
         */
        hid_write_report(in_report, hid_joy_report_in);
      }
      if(hat_state_changed) {
        hat_state_changed = FALSE;
        /* Write report data.
         */
        hid_write_report(in_report, hid_joy_report_in);      
      }
      /* Look for buttons state. 
       */
      cur_state = joy_scan_matrix();
      
      /* If the status of some buttons has been changed, update input
       * report.  
       */
      if (cur_state != last_state)
      {
        hid_write_report(in_report, hid_joy_report_in);
        last_state=cur_state;
      }
    }  
    
    busy_wait();
  }
  return(0);
}


/*
 * FUNCTION NAME: start_mS_timer:
 * DESCRIPTION:   to start a timer in milliseconds based on 1ms timer. 
 *                For fixed clock source, it is MCGFFCLK/2 as reference to TPM (see Figure 1-2. System Clock Distribution Diagram)
 *                For JM60/16, since the fixed clock is 1.5MHz derived from 12MHz external clock,
 *                TPM reference clcok is 1.5MHz/2 = 750KHz, and the TPM output clock is 5.859 KHz, after devided by 128. 
 *                With multiplication factor of 5 in MOD register and 
 *                it can achieve 0.9765625KHz, i.e. 1.024ms. The tolerance of the frequency is 6.15%.
 *                In addition, it can achieve 6.5s max.
 *                If MOD register value is M, then it will count M+1 prescaler clocks for free running counter.
 *                
 * INPUT PARAMETER:
 *    delay  -     the desired delay in millisconds
 * OUTPUT PARAMETER:
 * RETURN:
 */
void joy_start_mS_timer(hcc_u16 delay)
{     
 TPM1MOD = (delay*5);
 TPM1C0V = (delay*5);
 TPM1CNT = 0;
 TPM1SC_TOIE  = 1;       /* enable the timer overflow interrupt */
 TPM1C0SC_CH0IE = 1;
 TPM1SC_CPWMS = 0;
 TPM1C0SC_MS0x = 1;
 TPM1C0SC_ELS0x = 1;    /* toggle output */ 
 TPM1SC_PS =   7;        /* prescalor 128 */
 TPM1SC_CLKSA = 0;
 TPM1SC_CLKSB = 1;       /* select Fixed clock as source clock */

}

#define  VectorNumber_Vtpm1ovf           15
#define  VectorNumber_Vtpm1ch0           9


interrupt VectorNumber_Vtpm1ovf void  TPMOvrFlow() 
{

  hcc_u8 hat;
  
  /* Clear interrupt flag */
  TPM1SC_TOF = 0;
  
 #ifndef USE_POTENTIOMETER 
  hat = GET_RPT_IN_HAT(hid_joy_report_in);

  hat++;
  if(hat>3) {     /* hat should be within the range of [LOGICAL MINIMUM,MAXIMUM] */
    hat = 0;
  }
   /* Change the Hat switch */
  CHANGE_RPT_IN_HAT(hid_joy_report_in,hat);     
  hat_state_changed = TRUE;
 #endif
}

interrupt  VectorNumber_Vtpm1ch0 void TPMCHnEvent()
{ 
    signed short delta;
    
   /* Clear interrupt flag */
   TPM1C0SC_CH0F = 0;
 
 #ifdef  USE_ACCEROMETER  
   /* Get X value with scaled result. 
    * AdcResult of 0xFFF --> X of 127, and 0 --> X of -127 */
   ADC_Cvt(3); 
   delta =  (x -(AdcResult >>4));
   if( ((delta) >= XY_THRESHOLD) ||
       ((delta) < -XY_THRESHOLD)
    ) 
    {
      delta += DIR_REP_X(hid_joy_report_in);
     if(delta < -127){
        delta = -127;
     } else if(delta > 127) {
        delta = 127;
     }
    CHANGE_RPT_IN_X(hid_joy_report_in,delta);
     xy_state_changed = TRUE;
    }
   /* Get Y value with scaled result.
    */
   ADC_Cvt(0); 
   delta =  (y -(AdcResult >>4));
   if( ((delta) >= XY_THRESHOLD) ||
       ((delta) < -XY_THRESHOLD)
    ) 
   {
      delta += DIR_REP_Y(hid_joy_report_in);
     if(delta < -127){
        delta = -127;
     } else if(delta > 127) {
        delta = 127;
     }
    CHANGE_RPT_IN_Y(hid_joy_report_in,delta);
     xy_state_changed = TRUE;
   }
   
   /* Get throttle value with scaled result.
    * throttle is corresponding Z output of accerometer.
    */
   ADC_Cvt(1); 
   delta =  (throttle -(AdcResult >>4));
   if( ((delta) >= THROTTLE_THRESHOLD) ||
       ((delta) < -THROTTLE_THRESHOLD)
    ) 
   {
      delta += DIR_REP_THROTTLE(hid_joy_report_in);    
     if(delta < -127){
        delta = -127;
     } else if(delta > 127) {
        delta = 127;
     }
  
    CHANGE_RPT_IN_THROTTLE(hid_joy_report_in,delta);
    xy_state_changed = TRUE;
   }

 #else 
   if (x >= 127 )
   {
       south = FALSE; 
   } 
 
   if(y >= 127) {
       east = FALSE;
   } 
   if(throttle >= 127) {
       accer = FALSE;
   }
    if( x < -127) {
      south = TRUE;
   } 
    
   if( y < -127) {
      east = TRUE;
   }
   if(throttle < -127) {
      accer = TRUE;
   }
   if( south ){
      x++;
   } else {
      x--;
   }
   if( east ){
      y++;
   } else {
      y--;
   }
   if( accer ){
      throttle++;
   } else {
      throttle--;
   }  
   CHANGE_RPT_IN_X(hid_joy_report_in,x);
   CHANGE_RPT_IN_Y(hid_joy_report_in,y);
   CHANGE_RPT_IN_THROTTLE(hid_joy_report_in,throttle);
   
   xy_state_changed = TRUE;
  #endif
  #ifdef USE_POTENTIOMETER
   /* Get hat value
    */
   ADC_Cvt(9);
   hat = (AdcResult>>10);
   if( hat != (GET_RPT_IN_HAT(hid_joy_report_in))) {
    CHANGE_RPT_IN_HAT(hid_joy_report_in,hat);  
    hat_state_changed = TRUE;
  }  
  #endif   
}
/****************************** END OF FILE **********************************/
