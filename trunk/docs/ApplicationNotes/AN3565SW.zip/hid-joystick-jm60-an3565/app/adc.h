/*************************************************************************************************
 * Copyright (c) 2007, Freescale Semiconductor
 *
 * File name   : 	Adc.h
 * Project name: 	JM60 demo ( Evaluation) code
 *
 *
 * Description : This program is the demo code 
 *
 * History     :
 * 04/01/2007  : Initial Development
 * 
 *************************************************************************************************/

#ifndef _ADC_H
#define _ADC_H
#include <mc9s08jm60.h>

//#define ADC_INT_EN
#define ADC_POLLING

//#define EIGHTBIT_MODE
//#define TENBIT_MODE
#define TWELVEBIT_MODE

//#define BANDGAP_EN

extern volatile word AdcResult;


extern void ADC_Init(void);
extern void ADC_Cvt(unsigned char channel);
#endif