/*************************************************************************************************
 * Copyright (c) 2007, Freescale Semiconductor
 * Freescale Application Note
 *
 * File name   : Adc.c
 * Project name: JM60 Evaluation code
 * Description : This software is the demo code for JM60 USB,  ADC module 
 *               
 *
 * History     :
 * 04/01/07  : Initial Development
 * 
 *************************************************************************************************/

#include "adc.h"

volatile word  AdcResult;
volatile unsigned char CovEndFlag;

void ADC_Init(void);
void ADC_Cvt(unsigned char Channel);

void ADC_Poll(void);

/**********************************************************************************************
 * ADC_Init: This function initilizes the ADC module
 *
 * Parameters:      none
 *
 * Subfunctions:    none.
 *
 * Return:          void
 *********************************************************************************************/ 
void ADC_Init(void)
{
     ADCCFG = 0x61;     //busclk/2, Div by 8,ADCK = 1.5MHz
                        /*  0b0000000 0
                         *    ||||||| |__ bit0,1: ADICLK : input clock select   
                         *    |||||||_|
                         *    ||||||_____ bit2,3: MODE :  Conversion Mode selection
                         *    |||||_|  
                         *    ||||______ bit4:    ADLSMP: long sample time configuration
                         *    |||_______ bit5,6 : ADIV:   Clock Divide Select 
                         *    ||______| 
                         *    |_________ bit7:    ADLPC:  Low power configuration 
                         */
     
     ADCSC2 = 0x00;  //
                        /*  0b00000000
                         *    ||||||||__ bit0:   
                         *    |||||||___ bit1: 
                         *    ||||||____ bit2: 
                         *    |||||_____ bit3: 
                         *    ||||______ bit4: ACFGT: Compare function greater than enable
                         *    |||_______ bit5: ACFE : Compare enable
                         *    ||________ bit6: ADTRG: Conversion trigger select
                         *    |_________ bit7: ADACT: Convert active
                         */

  	 #ifdef TENBIT_MODE
      ADCCFG |= 0x08;
     #endif
     
     #ifdef TWELVEBIT_MODE
       ADCCFG |= 0x04;
     #endif
   
    /*Change the channel, to check the releation between pins and channels */
    APCTL1 = 0xFF;   //disable all ADC ports
    APCTL2 = 0x0F;
       
}



/****************************************************************************************
 * ADC_Cvt :  start to conversion of one channel
 * input:     channel is the channel number which will do conversion
 *
 * Return : None
 ***************************************************************************************/ 

void ADC_Cvt(unsigned char Channel) 
{
      #ifdef  ADC_INT_EN
          ADCSC1 = (Channel & ADCSC1_ADCH_MASK) | ADCSC1_AIEN_MASK;   //start the single conversion by software
      #else
          ADCSC1 = (Channel & ADCSC1_ADCH_MASK) ;   //start the single conversion by software
      #endif
       
      #ifdef ADC_POLLING
          ADC_Poll();
      #endif

}

/****************************************************************************************
 * ADCISR: The ADC interrupt service routine that reads the ADC data register and places
 *         the value into global variables resulth and resultl
 *
 * Parameters: None
 *
 * Return : None
 ***************************************************************************************/ 
void ADC_Poll(void) 
{
  while(!ADCSC1_COCO);
   AdcResult = ADCRH;
   AdcResult = (AdcResult<<8) | ADCRL;
//  AdcResult = ADCR;
  CovEndFlag = 1;
}

/****************************************************************************************
 * ADCISR: The ADC interrupt service routine which reads the ADC data register and places
 *         the value into global variables resulth and resultl
 *
 * Parameters: None
 *
 * Return : None
 ***************************************************************************************/ 
 interrupt 26 void ADCISR (void)
 {
    AdcResult = ADCR;
    
    CovEndFlag = 1;   
 }
