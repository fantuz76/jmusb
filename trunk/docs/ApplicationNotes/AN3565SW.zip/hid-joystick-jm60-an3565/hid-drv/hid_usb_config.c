/****************************************************************************
 *
 *            Copyright (c) 2006-2007 by CMX Systems, Inc.
 *
 * This software is copyrighted by and is the sole property of
 * CMX.  All rights, title, ownership, or other interests
 * in the software remain the property of CMX.  This
 * software may only be used in accordance with the corresponding
 * license agreement.  Any unauthorized use, duplication, transmission,
 * distribution, or disclosure of this software is expressly forbidden.
 *
 * This Copyright notice may not be removed or modified without prior
 * written consent of CMX.
 *
 * CMX reserves the right to modify this software without notice.
 *
 * CMX Systems, Inc.
 * 12276 San Jose Blvd. #511
 * Jacksonville, FL 32223
 * USA
 *
 * Tel:  (904) 880-1840
 * Fax:  (904) 880-1632
 * http: www.cmx.com
 * email: cmx@cmx.com
 *
 ***************************************************************************/
#include "usb.h"
#include "hid.h"


#define USB_FILL_OTG_DESC(hnp, srp) \
  (hcc_u8)3, 0x9, 0


#define USB_FILL_HID_DESC(length, hid_rel, country, ndesc, desc_type, desc_len) \
  (hcc_u8)(length), 0x21, (hcc_u8)(hid_rel), (hcc_u8)((hid_rel)>>8), (hcc_u8)(country)\
  ,(hcc_u8)(ndesc), (hcc_u8)(desc_type), (hcc_u8)(desc_len), (hcc_u8)((desc_len)>>8)


/* String descriptor 0:
 * Specifying Languages Supported by the Device.
 */
const hcc_u8 string_descriptor0[4] = {4, 0x3
                  , 0x09, 0x04 };

/* String descriptor for manufacturer: "Freescale"
 */                  
const hcc_u8 str_manufacturer[20] = { 20, 0x3
                  , 'F',0, 'r',0, 'e',0, 'e',0,'s',0, 'c',0, 'a',0, 'l',0, 'e',0
                  };


/************************************* joystick *****************************/
#define JOY_VENDOR_ID   0x0425 //0xc1cau
#define JOY_PRODUCT_ID  (0x8888u)
#define JOY_DEVICE_REL_NUM  0x0

/* UNICODE string descriptor for configuration "Default configuration"
 */
const hcc_u8 joy_config[44] = { 44, 0x3
                  , 'D',0, 'e',0, 'f',0, 'a',0, 'u',0
                  , 'l',0, 't',0, ' ',0, 'c',0, 'o',0, 'n',0, 'f',0, 'i',0
                  , 'g',0, 'u',0, 'r',0, 'a',0, 't',0, 'i',0, 'o',0, 'n',0};
/* UNICODE string descriptor for interface "HID-Joystick"
 */
const hcc_u8 joy_interface[26] = { 26, 0x3
                  , 'H',0, 'I',0, 'D',0, '-',0, 'J',0
                  , 'o',0, 'y',0, 's',0, 't',0,'i',0,'c',0,'k',0 };

/* UNICODE string descriptor for serial number "V0.01"
 */

const hcc_u8 joy_serail_number[10] = { 10, 0x3
                  , 'V',0, '0',0, '.',0, '1',0};

/* UNICODE string descriptor for product "USB HID Joystick demo for HC9S08JM devices by William Jiang"
 */
const hcc_u8 joy_product[120] = { 120, 0x3
                  , 'U',0, 'S',0, 'B',0, ' ',0, 'H',0, 'I',0, 'D',0, ' ',0
                  , 'J',0, 'o',0, 'y',0, 's',0, 't',0, 'i',0, 'c',0, 'k',0
                  , ' ',0, 'd',0, 'e',0, 'm',0, 'o',0, ' ',0, 'f',0, 'o',0
                  , 'r',0, ' ',0, 'H',0, 'C',0, '9',0, 'S',0, '0',0, '8',0
                  , 'J',0, 'M',0, ' ',0, 'd',0, 'e',0, 'v',0, 'i',0, 'c',0
                  , 'e',0, 's',0, ' ',0, 'b',0, 'y',0, ' ',0, 'W',0, 'i',0
                  , 'l',0, 'l',0, 'i',0, 'a',0, 'm',0, ' ',0, 'J',0, 'i',0
                  , 'a',0, 'n',0, 'g',0
                  };

/* The array of String descriptors
 */
const hcc_u8 * const joy_string_descriptors[] = {
  string_descriptor0, str_manufacturer, 
  joy_product,joy_serail_number,
  joy_config, joy_interface
};


/* Device Descriptor for joystick
 */
const hcc_u8 joy_device_descriptor[] = {
  USB_FILL_DEV_DESC(0x0101, 0, 0, 0, EP0_PACKET_SIZE, 
  JOY_VENDOR_ID, JOY_PRODUCT_ID,JOY_DEVICE_REL_NUM,
  1, 2, 3, 1)
};


/* HID Report descriptor for joystick created by USB HID Descriptor Tool DT.exe
 */
const hcc_u8 joy_report_descriptor[76] = { 
    0x05, 0x01,                    // USAGE_PAGE (Generic Desktop)
    0x09, 0x04,                    // USAGE (Joystick)
    0xa1, 0x01,                    // COLLECTION (Application)
    0x05, 0x02,                    //   USAGE_PAGE (Simulation Controls)
    0x09, 0xbb,                    //   USAGE (Throttle)
    0x15, 0x81,                    //   LOGICAL_MINIMUM (-127)
    0x25, 0x7f,                    //   LOGICAL_MAXIMUM (127)
    0x35, 0x00,                    //   PHYSICAL_MINIMUM (0)
    0x46, 0xff, 0x00,              //   PHYSICAL_MAXIMUM (255)
    0x75, 0x08,                    //   REPORT_SIZE (8)
    0x95, 0x01,                    //   REPORT_COUNT (1)
    0x81, 0x02,                    //   INPUT (Data,Var,Abs)
    0x05, 0x01,                    //   USAGE_PAGE (Generic Desktop)
    0x09, 0x01,                    //   USAGE (Pointer)
    0xa1, 0x00,                    //   COLLECTION (Physical)
    0x09, 0x30,                    //     USAGE (X)
    0x09, 0x31,                    //     USAGE (Y)
    0x95, 0x02,                    //     REPORT_COUNT (2)
    0x81, 0x02,                    //     INPUT (Data,Var,Abs)
    0xc0,                          //     END_COLLECTION
    0x09, 0x39,                    //   USAGE (Hat switch)
    0x15, 0x00,                    //   LOGICAL_MINIMUM (0)
    0x25, 0x03,                    //   LOGICAL_MAXIMUM (3)
    0x35, 0x00,                    //   PHYSICAL_MINIMUM (0)
    0x46, 0x0e, 0x01,              //   PHYSICAL_MAXIMUM (270)
    0x65, 0x14,                    //   UNIT (Eng Rot:Angular Pos)
    0x75, 0x04,                    //   REPORT_SIZE (4)
    0x95, 0x01,                    //   REPORT_COUNT (1)
    0x81, 0x02,                    //   INPUT (Data,Var,Abs)
    0x05, 0x09,                    //   USAGE_PAGE (Button)
    0x19, 0x01,                    //   USAGE_MINIMUM (Button 1)
    0x29, 0x04,                    //   USAGE_MAXIMUM (Button 4)
    0x25, 0x01,                    //   LOGICAL_MAXIMUM (1)
    0x15, 0x00,                    //   LOGICAL_MINIMUM (0)
    0x75, 0x01,                    //   REPORT_SIZE (1)
    0x95, 0x04,                    //   REPORT_COUNT (4)
    0x81, 0x02,                    //   INPUT (Data,Var,Abs)
    0xc0                           // END_COLLECTION
};

 
/* Configuration descriptor for joystick
 * which returns configuration descriptor,  
 */ 
#define CONFIGURATION_VALUE   1 
const hcc_u8 joy_config_descriptor[] = {
  USB_FILL_CFG_DESC(9+3+9+9+7, 1, CONFIGURATION_VALUE, 4, CFGD_ATTR_SELF_PWR, 0x10), /* Configuration descriptor */
  USB_FILL_OTG_DESC(1, 1),                                  /* OTG descriptor */
  USB_FILL_IFC_DESC(JOY_IFC_INDEX, 0, 1, 0x3, 0x0, 0x0, 5), /* Interface descriptor: HID,0, 0 (3/1/2) */
  USB_FILL_HID_DESC(9, 0x0100, 0x0, 1, 0x22, sizeof(joy_report_descriptor)), /* HID descriptor */
  USB_FILL_EP_DESC(0x1, 1, 0x3, 8, 0x20),                   /* Endpoint descriptors */
};


/* Descriptor information structure
 */
descriptor_info_t di;



/*****************************************************************************
 * HID reset event handler. 
 ****************************************************************************/
void got_usb_reset(void)
{
  /* empty */
}

/*****************************************************************************
 * Return the HID descriptor for the selected device.
 ****************************************************************************/
descriptor_info_t *get_hid_descriptor(void)
{
  di.start_addr=(void *)(joy_config_descriptor+9+3+9);
  di.size=9;    

  return(&di);
}

/*****************************************************************************
 * Return the report descriptor for the selected device.
 ****************************************************************************/
descriptor_info_t *get_report_descriptor(void)
{
   di.start_addr=(void *)joy_report_descriptor;
   di.size=sizeof(joy_report_descriptor);    
   
   return(&di);
}

/*****************************************************************************
 * Return the physical descriptor for the selected device.
 ****************************************************************************/
descriptor_info_t *get_physical_descriptor(hcc_u8 id)
{
  switch(id)
  {
    default:
     return(0);
  }    
}


/*****************************************************************************
 * Return the USB device descriptor.
 ****************************************************************************/
void* get_device_descriptor(void)
{
   return((void *)joy_device_descriptor);
}

/*****************************************************************************
 * Return !=0 if the specified index is the index of a configuration.
 ****************************************************************************/
hcc_u8 is_cfgd_index(hcc_u16 cndx)
{
    return((hcc_u8)(cndx == CONFIGURATION_VALUE ? 1u : 0u));
}

/*****************************************************************************
 * Return the selected configuration descriptor.
 ****************************************************************************/
void *get_cfg_descriptor(hcc_u8 cndx)
{
   if(cndx != CONFIGURATION_VALUE) {
    return 0;
   }
   return((void *)joy_config_descriptor);
}

/*****************************************************************************
 * Return !=0 if a string descriptor exist whit the specified index.
 ****************************************************************************/
hcc_u8 is_str_index(hcc_u8 sndx)
{
    return ((hcc_u8)(sndx < sizeof(joy_string_descriptors)/sizeof(joy_string_descriptors[0])
             ? 1u : 0u));
}

/*****************************************************************************
 * Get the specified string descriptor.
 ****************************************************************************/
void *get_str_descriptor(hcc_u8 sndx)
{
//   di.size=sizeof(joy_string_descriptors[sndx]);        
    return ((void*)joy_string_descriptors[sndx]);
}

/*****************************************************************************
 * Return !=0 if the secified interface exist.
 ****************************************************************************/
hcc_u8 is_ifc_ndx(hcc_u8 cndx, hcc_u8 indx, hcc_u8 iset)
{ 
    if (cndx != CONFIGURATION_VALUE || iset !=0)
    {
      return(0); 
    }
    return((hcc_u8)(indx < 1 ? 1 : 0));
}

/*****************************************************************************
 * Return !=0 if the specified endpoint exist.
 ****************************************************************************/
hcc_u8 is_ep_ndx(hcc_u8 cndx, hcc_u8 indx, hcc_u8 iset, hcc_u8 endx)
{
    if (cndx != CONFIGURATION_VALUE || indx !=0  || iset !=0)
    {
      return(0); 
    }
    return((hcc_u8)(endx < 1 ? 1 : 0));
}

/*****************************************************************************
 * Return the endpoint descriptor of the specified endpoint.
 ****************************************************************************/
void *get_ep_descriptor(hcc_u8 cndx, hcc_u8 indx, hcc_u8 iset, hcc_u8 endx)
{
    return((void*)(joy_config_descriptor+9+3+9+9));
}


callback_state_t usb_ep0_callback(void)
{
  return(usb_ep0_hid_callback());
}

void usb_cfg_init(void)
{
  (void)usb_init();
}
/****************************** END OF FILE **********************************/
